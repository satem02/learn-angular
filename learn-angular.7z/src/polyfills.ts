import 'zone.js/dist/zone';  // Included with Angular CLI.
import 'hammerjs';
import 'web-animations-js';
