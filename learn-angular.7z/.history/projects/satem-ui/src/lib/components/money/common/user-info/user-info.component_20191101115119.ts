import { Component, OnInit, Output, EventEmitter } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { UserInfo } from "projects/satem-ui/src/lib/models";

@Component({
  selector: "satem-ui-user-info",
  templateUrl: "./user-info.component.html",
  styleUrls: ["./user-info.component.css"]
})
export class UserInfoComponent implements OnInit {
  userInfoFormGroup: FormGroup;
  public model = {} as UserInfo;

  @Output() private onFormGroupChange = new EventEmitter<any>();

  constructor(private formBuilder: FormBuilder) {}

  ngOnInit() {
    this.createForm();
    this.onFormGroupChange.emit(this.userInfoFormGroup);
  }

  createForm() {
    this.userInfoFormGroup = this.formBuilder.group({
      name: [],
      username: []
    });
  }
}
