import { Component, OnInit } from "@angular/core";
import {
  FormControl,
  FormGroup,
  ControlContainer,
  FormGroupDirective,
  Validators,
  FormBuilder,
  NgModel
} from "@angular/forms";
import { LoginUserInfo } from "projects/satem-ui/src/lib/models";

@Component({
  selector: "satem-ui-user-info",
  templateUrl: "./user-info.component.html",
  styleUrls: ["./user-info.component.scss"],
  viewProviders: [
    { provide: ControlContainer, useExisting: FormGroupDirective }
  ]
})
export class UserInfoComponent implements OnInit {
  childForm;
  userModel: LoginUserInfo = new LoginUserInfo();
  
  constructor(private parentF: FormGroupDirective) {}

  ngOnInit() {
    this.childForm = this.parentF.form;
    this.childForm.addControl(
      "_general",
      new FormGroup({
        userName: new FormControl(""),
        password: new FormControl("")
      })
    );
  }
}
