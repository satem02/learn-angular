export * from './parent/parent.component';
export * from './child-one/child-one.component';
export * from './child-two/child-two.component';