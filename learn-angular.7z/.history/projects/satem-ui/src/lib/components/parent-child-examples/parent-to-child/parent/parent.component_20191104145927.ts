import { Component, OnInit } from "@angular/core";
import { FlowInfo } from "../models/flow-model";
import { FormGroup, FormBuilder } from "@angular/forms";

@Component({
  selector: "satem-ui-parent",
  templateUrl: "./parent.component.html",
  styleUrls: ["./parent.component.scss"]
})
export class ParentComponent implements OnInit {
  parentFormGroup: FormGroup;
  model: FlowInfo = new FlowInfo();

  constructor(private formBuilder: FormBuilder) {}

  ngOnInit() {}
  
  createForm() {
    this.parentFormGroup = this.formBuilder.group({
      name: [],
      surName: []
    });
  }

  nextButtonClicked() {}
}
