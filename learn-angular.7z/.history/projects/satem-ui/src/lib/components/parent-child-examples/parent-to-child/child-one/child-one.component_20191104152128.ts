import { Component, OnInit, Input } from "@angular/core";
import { ContactInfo } from "../models";
import { FormBuilder, FormGroup } from "@angular/forms";

@Component({
  selector: "satem-ui-child-one",
  templateUrl: "./child-one.component.html",
  styleUrls: ["./child-one.component.scss"]
})
export class ChildOneComponent implements OnInit {
  childOneFormGroup: FormGroup;
  @Input() parentFormGroup: FormGroup;
  @Input() childPropertyName : string;

  model: ContactInfo = new ContactInfo();

  constructor(private formBuilder: FormBuilder) {}

  ngOnInit() {
    this.createForm();
    this.addGroupToParent();
  }

  createForm() {
    this.childOneFormGroup = this.formBuilder.group({
      mail: [],
      phone: []
    });
  }

  private addGroupToParent() {
    this.parentFormGroup.addControl(
      "contact",  // 
      this.childOneFormGroup
    );
  }
}
