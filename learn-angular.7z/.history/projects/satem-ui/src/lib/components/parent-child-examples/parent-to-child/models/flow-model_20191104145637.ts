import { ContactInfo, UserInfo, AddressInfo } from ".";

export class FlowInfo {
  public user: UserInfo = new UserInfo();
  public contact: ContactInfo = new ContactInfo();
  public address: AddressInfo = new AddressInfo();
}
