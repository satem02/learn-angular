import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'satem-ui-address-info',
  templateUrl: './address-info.component.html',
  styleUrls: ['./address-info.component.css']
})
export class AddressInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
