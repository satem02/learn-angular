export class AddressInfo {
  public country: string;
  public city: string;
}
