import { Component, OnInit, Input } from "@angular/core";
import { FormGroup } from "@angular/forms";

@Component({
  selector: "satem-ui-child-base"
})
export class ChildBaseComponent implements OnInit {
  @Input() childTwoFormGroup: FormGroup;
  @Input() parentFormGroup: FormGroup;
  @Input() childPropertyName: string;

  constructor() {}

  ngOnInit() {
    this.addGroupToParent();
  }

  private addGroupToParent() {
    this.parentFormGroup.addControl(
      this.childPropertyName,
      this.childTwoFormGroup
    );
  }
}
