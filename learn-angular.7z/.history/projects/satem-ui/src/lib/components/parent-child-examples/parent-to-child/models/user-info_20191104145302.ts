export class UserInfo {
  public userName: string;
  public password: string;
}

