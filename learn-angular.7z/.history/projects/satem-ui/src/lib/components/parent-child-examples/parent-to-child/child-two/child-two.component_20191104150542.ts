import { Component, OnInit } from '@angular/core';
import { AddressInfo } from '../models';

@Component({
  selector: 'satem-ui-child-two',
  templateUrl: './child-two.component.html',
  styleUrls: ['./child-two.component.scss']
})
export class ChildTwoComponent implements OnInit {

  model:AddressInfo = new AddressInfo();
  
  constructor() { }

  ngOnInit() {
  }

}
