export class ContactInfo {
  public mail: string;
  public phone: string;
}
