import { Component, OnInit } from '@angular/core';
import { FlowInfo } from '../models/flow-model';

@Component({
  selector: 'satem-ui-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.scss']
})
export class ParentComponent implements OnInit {

  model : FlowInfo =  new FlowInfo();
  
  constructor() { }

  ngOnInit() {
  }


  nextButtonClicked(){
    
  }
}
