import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'satem-ui-contact-info',
  templateUrl: './contact-info.component.html',
  styleUrls: ['./contact-info.component.css']
})
export class ContactInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
