import { UserInfo, ContactInfo, AddressInfo } from '../models';

export class MainInfo {
  public name: string;
  public customer: UserInfo = new UserInfo();  
  public contact: ContactInfo = new ContactInfo();
  public address: AddressInfo = new AddressInfo();
}
