import { Component, OnInit } from "@angular/core";
import { ChildBaseComponent } from "../../base/child-base-component";

@Component({
  selector: "satem-ui-customer-info",
  templateUrl: "./customer-info.component.html",
  styleUrls: ["./customer-info.component.scss"]
})
export class CustomerInfoComponent extends ChildBaseComponent
  implements OnInit {
    
  constructor() {
    super();
  }

  ngOnInit() {}
}
