import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'satem-ui-child-one',
  templateUrl: './child-one.component.html',
  styleUrls: ['./child-one.component.scss']
})
export class ChildOneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
