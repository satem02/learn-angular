import { Component, OnInit, Input } from "@angular/core";
import { FormGroup } from "@angular/forms";

@Component({
  selector: "satem-ui-child-base"
})
export class ChildBaseComponent {

  @Input() parentFormGroup: FormGroup;
  @Input() childPropertyName: string;
  private childFormGroup: FormGroup;

  public addGroupToParent(form: FormGroup) {
    this.childFormGroup = form;
    this.parentFormGroup.addControl(
      this.childPropertyName,
      this.childFormGroup
    );
  }
}
