import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'satem-ui-address-info',
  templateUrl: './address-info.component.html',
  styleUrls: ['./address-info.component.scss']
})
export class AddressInfoComponent  extends ChildBaseComponent implements OnInit {
  
  childOneFormGroup: FormGroup;
  model: ContactInfo = new ContactInfo();

  constructor(private formBuilder: FormBuilder) {
    super();
  }

  ngOnInit() {
    this.createForm();
  }

  createForm() {
    this.childOneFormGroup = this.formBuilder.group({
      mail: [],
      phone: []
    });
    // parent forma ekleme metodu . base classdan geliyor.
    this.addGroupToParent(this.childOneFormGroup);
  }
}
