import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'satem-ui-child-two',
  templateUrl: './child-two.component.html',
  styleUrls: ['./child-two.component.scss']
})
export class ChildTwoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
