import { Component, OnInit, Input } from "@angular/core";
import { FormGroup } from "@angular/forms";

@Component({
  selector: "satem-ui-child-base"
})
export class ChildBaseComponent implements OnInit {
  constructor(
    public childPropertyName: string,
    public childTwoFormGroup: FormGroup,
    public parentFormGroup: FormGroup
  ) {}

  ngOnInit() {
    this.addGroupToParent();
  }

  private addGroupToParent() {
    this.parentFormGroup.addControl(
      this.childPropertyName,
      this.childTwoFormGroup
    );
  }
}
