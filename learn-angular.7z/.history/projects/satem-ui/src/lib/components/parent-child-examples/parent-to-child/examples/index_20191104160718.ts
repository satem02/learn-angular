export * from "./address-info/address-info.component";
export * from "./contact-info/contact-info.component";
export * from "./customer-info/customer-info.component";
