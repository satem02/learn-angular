import { Component, OnInit } from '@angular/core';
import { AddressInfo } from '../models';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'satem-ui-child-two',
  templateUrl: './child-two.component.html',
  styleUrls: ['./child-two.component.scss']
})
export class ChildTwoComponent implements OnInit {
  parentFormGroup: FormGroup;

  model:AddressInfo = new AddressInfo();

  constructor(private formBuilder: FormBuilder) {}

  ngOnInit() {
    this.createForm();
  }

  createForm() {
    this.parentFormGroup = this.formBuilder.group({
      name: [],
      surName: []
    });
  }


}
