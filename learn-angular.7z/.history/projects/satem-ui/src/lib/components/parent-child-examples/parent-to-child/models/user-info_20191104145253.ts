export class UserInfo {
  public userName: string;
  public password: string;
}

export class ContactInfo {
  public mail: string;
  public phone: string;
}
