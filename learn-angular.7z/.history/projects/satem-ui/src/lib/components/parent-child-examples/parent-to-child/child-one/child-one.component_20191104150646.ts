import { Component, OnInit } from '@angular/core';
import { ContactInfo } from '../models';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'satem-ui-child-one',
  templateUrl: './child-one.component.html',
  styleUrls: ['./child-one.component.scss']
})
export class ChildOneComponent implements OnInit {
  childOneFormGroup: FormGroup;

  model:ContactInfo = new ContactInfo();

  constructor(private formBuilder: FormBuilder) {}

  ngOnInit() {
    this.createForm();
  }

  createForm() {
    this.childOneFormGroup = this.formBuilder.group({
      name: [],
      surName: []
    });
  }

  

}
