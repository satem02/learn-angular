import { ContactInfo } from '.';

export class FlowInfo {
    public user: UserInfo;
    public contact: ContactInfo;
    public address: AddressInfo;
  }
  