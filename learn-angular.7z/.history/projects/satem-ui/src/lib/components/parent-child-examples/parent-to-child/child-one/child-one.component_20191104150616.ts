import { Component, OnInit } from '@angular/core';
import { ContactInfo } from '../models';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'satem-ui-child-one',
  templateUrl: './child-one.component.html',
  styleUrls: ['./child-one.component.scss']
})
export class ChildOneComponent implements OnInit {

  model:ContactInfo = new ContactInfo();
  
  constructor(private formBuilder: FormBuilder) {}

  ngOnInit() {
    this.createForm();
  }

  createForm() {
    this.parentFormGroup = this.formBuilder.group({
      name: [],
      surName: []
    });
  }

  

}
