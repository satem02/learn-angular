import { Component, OnInit } from '@angular/core';
import { AddressInfo } from '../models';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'satem-ui-child-two',
  templateUrl: './child-two.component.html',
  styleUrls: ['./child-two.component.scss']
})
export class ChildTwoComponent implements OnInit {
  childTwoFormGroup: FormGroup;

  model:AddressInfo = new AddressInfo();

  constructor(private formBuilder: FormBuilder) {}

  ngOnInit() {
    this.createForm();
  }

  createForm() {
    this.childTwoFormGroup = this.formBuilder.group({
      name: [],
      surName: []
    });
  }


}
