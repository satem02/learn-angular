import { Component, OnInit } from '@angular/core';
import { ContactInfo } from '../models';

@Component({
  selector: 'satem-ui-child-one',
  templateUrl: './child-one.component.html',
  styleUrls: ['./child-one.component.scss']
})
export class ChildOneComponent implements OnInit {

  model:ContactInfo = new ContactInfo();
  
  constructor() { }

  ngOnInit() {
  }

}
