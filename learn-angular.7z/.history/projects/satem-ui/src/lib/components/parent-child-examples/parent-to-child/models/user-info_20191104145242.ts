export class UserInfo {
  public userName: string;
  public password: string;
}


export class AddressInfo {
  public country: string;
  public city: string;
}

export class ContactInfo {
  public mail: string;
  public phone: string;
}
