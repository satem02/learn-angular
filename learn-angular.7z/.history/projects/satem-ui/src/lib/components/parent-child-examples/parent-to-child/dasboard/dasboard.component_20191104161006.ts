import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'satem-ui-dasboard',
  templateUrl: './dasboard.component.html',
  styleUrls: ['./dasboard.component.2css']
})
export class DasboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
