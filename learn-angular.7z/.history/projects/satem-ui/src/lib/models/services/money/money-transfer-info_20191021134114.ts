export interface MoneyTransferInfo {
    email: string;
    name: string;
}