export class LoginUserInfo {
  public userName: string;
  public password: string;
}
