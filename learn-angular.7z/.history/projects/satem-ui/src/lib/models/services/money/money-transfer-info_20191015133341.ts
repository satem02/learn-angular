export class MoneyTransferInfo {

}