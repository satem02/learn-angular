export class LoginUserInfo {
  public name: string;
  public surName: string;
}
