export class ChoiceInfo{
    key:string;
    value:string;
}