export class MoneyTransferInfo {
  public name: string;
  public surName: string;
}
