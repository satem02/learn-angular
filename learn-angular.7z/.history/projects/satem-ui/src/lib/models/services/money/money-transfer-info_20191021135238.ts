export class MoneyTransferInfo {
    public email: string;
    public name: string;
}