export class UserInfo {
  public name: string;
  public surName: string;
}
