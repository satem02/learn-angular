export class MoneyTransferInfo {
    email: string;
    name: string;
}