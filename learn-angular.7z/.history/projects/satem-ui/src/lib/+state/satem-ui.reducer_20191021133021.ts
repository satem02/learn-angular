
import { Action, createReducer, on } from "@ngrx/store";
import {  MoneyTransferInfo, UserInfo } from '../models';
import {  getMoneyTransferInformation, loadUsersLoaded } from './satem-ui.action';


export interface SatemUIState {
    users: UserInfo[];
    moneyTransferInformation: MoneyTransferInfo;
}

export const satemUIStateInitialState: SatemUIState = {
    users: [],
    moneyTransferInformation: new MoneyTransferInfo()
};

export const reducer = createReducer(
    satemUIStateInitialState,
    on(loadUsersLoaded, (state, payload) => ({
        ...state,
        users: payload.users
    })),
    on(setMoneyTransferInformation, (state, payload) => ({
        ...state,
        moneyTransferInformation: payload.moneyTransferInformation
    }))
);

export function satemUIReducer(state: SatemUIState | undefined, action: Action) {
    return reducer(state, action);
}
