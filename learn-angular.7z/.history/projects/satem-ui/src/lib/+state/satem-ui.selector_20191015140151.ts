import { createFeatureSelector, createSelector } from '@ngrx/store';
import { SatemUIState } from './satem-ui.reducer';

const getSatemUIState = createFeatureSelector<SatemUIState>('satemUIState');

export const getUsers = createSelector(getSatemUIState, (state: SatemUIState) => state.users);
export const getMoneyTransferInfo = createSelector(getSatemUIState, (state: SatemUIState) => state.moneyTransferInformation);


export const satemUIStateQuery = {
    getUsers: getUsers,
    getMoneyTransferInfo:getMoneyTransferInfo
}
