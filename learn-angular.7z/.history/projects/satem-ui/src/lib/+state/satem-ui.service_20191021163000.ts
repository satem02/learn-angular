import { Injectable } from '@angular/core';
import { Observable } from "rxjs/internal/Observable";
import { map, tap } from "rxjs/operators";
import { ApiService, GenericResponseType } from '../services';
import { MoneyTransferRequest, MoneyTransferInfo, UserInfo } from '../models';
import { ChoiceInfo } from '../models/services/common/choice-info';

@Injectable()
export class SatemUIService {

    private readonly baseURL = '';
    private readonly usersInfoUriBase = this.baseURL;
    private readonly moneyRequestUriBase = this.baseURL + '\RequestMoney';


    constructor(private apiService: ApiService) {
    }

    loadUsers(): Observable<UserInfo[]> {
        return this.apiService
            .get(`${this.usersInfoUriBase}users`)
            .pipe(
                map((response: any) => response)
            );
    }

    loadCurrencies(): Observable<ChoiceInfo[]> {
        return this.apiService
        .get(`${this.usersInfoUriBase}currencies`).pipe(
          map((response: any) => response),
          tap(res => console.log("call getCurrencies"))
        );
    }

    loadMoneyTransferRequest(input: MoneyTransferRequest): Observable<MoneyTransferInfo[]> {
        return this.apiService
            .post(`${this.moneyRequestUriBase}/getMoneyRequest`, input)
            .pipe(
                map((response: GenericResponseType<any>) => response.dataOutput)
            );
    }

}