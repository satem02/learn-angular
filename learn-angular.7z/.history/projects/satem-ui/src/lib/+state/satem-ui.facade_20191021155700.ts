import { Injectable } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs/internal/Observable';
import {  MoneyTransferInfo, UserInfo } from '../models';
import { SatemUIState } from './satem-ui.reducer';
import { satemUIStateQuery } from './satem-ui.selector';
import * as rootActions from './satem-ui.action';
import { ChoiceInfo } from '../models/services/common/choice-info';


@Injectable({
    providedIn: 'root'
})
export class SatemUIFacade {

    users$: Observable<UserInfo[]>;
    moneyTransferInformation$: Observable<MoneyTransferInfo>;

    constructor(private store: Store<SatemUIState>) {
        this.users$ = store.pipe(select(satemUIStateQuery.getUsers));
        this.moneyTransferInformation$ = store.pipe(select(satemUIStateQuery.setMoneyTransferInfo));
    }

    loadUsers() {
        this.store.dispatch(rootActions.loadUsers({  }));
    }

    setMoneyTransferInformation(moneyTransferInformation: MoneyTransferInfo) {
        this.store.dispatch(rootActions.setMoneyTransferInformation({ moneyTransferInformation }));
    }

    loadCurrecnyTypes(): Observable<ChoiceInfo[]> {
        const currencyTypesList = new Observable<ChoiceInfo[]>(observer => {
            observer.next([
              { key: "TL", value: "TRY" },
              { key: "USD", value: "USD" }
            ]);
        });
    
        return currencyTypesList;
      }
}
