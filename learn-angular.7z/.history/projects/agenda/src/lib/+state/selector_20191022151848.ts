import { createFeatureSelector, createSelector } from '@ngrx/store';
import { StateReducer } from './reducer';

const getState = createFeatureSelector<StateReducer>('StateReducer');

export const getUsers = createSelector(getState, (state: StateReducer) => state.users);


export const stateQuery = {
    getUsers: getUsers
}
