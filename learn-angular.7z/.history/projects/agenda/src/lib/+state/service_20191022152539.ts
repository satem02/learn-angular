import { Injectable } from "@angular/core";
import { Observable } from "rxjs/internal/Observable";
import { map, tap } from "rxjs/operators";
import { EventInfo } from '../models';


@Injectable()
export class StateService {
  private readonly baseURL = "";
  private readonly usersInfoUriBase = this.baseURL;

  constructor(private apiService: ApiService) {}

  loadEvents(): Observable<EventInfo[]> {
    return this.apiService
      .get(`${this.usersInfoUriBase}users`)
      .pipe(map((response: any) => response));
  }

}
