import { Injectable } from "@angular/core";
import { select, Store } from "@ngrx/store";
import { Observable } from "rxjs/internal/Observable";
import { SatemUIState } from "./reducer";
import { stateQuery } from "./selector";
import * as rootActions from "./action";

@Injectable({
  providedIn: "root"
})
export class StateFacade {
  users$: Observable<UserInfo[]>;

  constructor(private store: Store<StateState>) {
    this.users$ = store.pipe(select(stateQuery.getUsers));
  }

  loadUsers() {
    this.store.dispatch(rootActions.loadUsers({}));
  }
}
