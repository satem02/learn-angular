import { Action, createReducer, on } from "@ngrx/store";
import {
  loadUsersLoaded
} from "./action";

export interface StateReducer {
  users: UserInfo[];
}

export const initialState: StateReducer = {
  users: []
};

export const reducer = createReducer(
  initialState,
  on(loadUsersLoaded, (state, payload) => ({
    ...state,
    users: payload.users
  }))
);

export function stateReducer(
  state: StateReducer | undefined,
  action: Action
) {
  return reducer(state, action);
}
