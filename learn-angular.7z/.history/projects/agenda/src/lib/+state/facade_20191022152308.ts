import { Injectable } from "@angular/core";
import { select, Store } from "@ngrx/store";
import { Observable } from "rxjs/internal/Observable";
import { StateReducer } from "./reducer";
import { stateQuery } from "./selector";
import * as rootActions from "./action";
import { EventInfo } from '../models';

@Injectable({
  providedIn: "root"
})
export class StateFacade {
  users$: Observable<EventInfo[]>;

  constructor(private store: Store<StateReducer>) {
    this.users$ = store.pipe(select(stateQuery.getUsers));
  }

  loadEvents() {
    this.store.dispatch(rootActions.loadEvents({}));
  }
}
