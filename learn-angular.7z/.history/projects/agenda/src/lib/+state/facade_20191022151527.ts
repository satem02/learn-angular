import { Injectable } from "@angular/core";
import { select, Store } from "@ngrx/store";
import { Observable } from "rxjs/internal/Observable";
import { MoneyTransferInfo, UserInfo, ChoiceInfo } from "../models";
import { SatemUIState } from "./satem-ui.reducer";
import { satemUIStateQuery } from "./satem-ui.selector";
import * as rootActions from "./satem-ui.action";

@Injectable({
  providedIn: "root"
})
export class StateFacade {
  users$: Observable<UserInfo[]>;

  constructor(private store: Store<StateState>) {
    this.users$ = store.pipe(select(stateQuery.getUsers));
  }

  loadUsers() {
    this.store.dispatch(rootActions.loadUsers({}));
  }
}
