import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { Injectable } from '@angular/core';
import { of } from "rxjs/internal/observable/of";
import { catchError, concatMap, map } from "rxjs/operators";
import * as stateActions from './action';
import { Service } from './service';

@Injectable()
export class Effects {

    loadUsers = createEffect(() =>
        this.actions$.pipe(
            ofType(stateActions.loadUsers),
            concatMap(action =>
                this.service
                    .loadUsers()
                    .pipe(
                        map((results) => stateActions.loadUsersLoaded({ users: results })),
                        catchError((error: Error) => of(stateActions.loadUsersLoadFail({ error: error })))
                    )
            )
        )
    );

    

    constructor(private actions$: Actions,
        private store: Store<any>,
        private service: Service) {
    }

}
