import { createAction, props } from "@ngrx/store";
import { MoneyTransferInfo, UserInfo, ChoiceInfo } from "../models";

export const loadUsers = createAction(
  "[SatemUI Users Info] Load Users Info",
  props<{}>()
);
export const loadUsersLoaded = createAction(
  "[SatemUI Users Info] Users Info Loaded",
  props<{ users: UserInfo[] }>()
);
export const loadUsersLoadFail = createAction(
  "[SatemUI Users Info] Users Info Failed",
  props<{ error: Error }>()
);


export const serviceError = createAction(
  "[article] LOAD_SERVICE_ERROR",
  props<{ error: Error }>()
);
