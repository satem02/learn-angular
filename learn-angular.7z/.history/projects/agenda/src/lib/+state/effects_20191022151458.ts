import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { Injectable } from '@angular/core';
import { of } from "rxjs/internal/observable/of";
import { catchError, concatMap, map } from "rxjs/operators";
import * as stateActions from './action';
import { StateService } from './service';

@Injectable()
export class StateEffects {

    loadUsers = createEffect(() =>
        this.actions$.pipe(
            ofType(stateActions.loadUsers),
            concatMap(action =>
                this.stateService
                    .loadUsers()
                    .pipe(
                        map((results) => stateActions.loadUsersLoaded({ users: results })),
                        catchError((error: Error) => of(stateActions.loadUsersLoadFail({ error: error })))
                    )
            )
        )
    );

    

    constructor(private actions$: Actions,
        private store: Store<any>,
        private stateService: StateService) {
    }

}
