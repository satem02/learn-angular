import { NgModule } from '@angular/core';
import { AgendaComponent } from './agenda.component';



@NgModule({
  declarations: [AgendaComponent],
  imports: [
  ],
  exports: [AgendaComponent]
})
export class AgendaModule { }
