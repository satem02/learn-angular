export interface EventInfo{
    key:string;
    value:string;
}