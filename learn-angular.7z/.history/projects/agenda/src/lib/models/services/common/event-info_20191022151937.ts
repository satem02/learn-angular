export interface ChoiceInfo{
    key:string;
    value:string;
}