/*
 * Public API Surface of agenda
 */

export * from './lib/components/event-list/event-list.component';