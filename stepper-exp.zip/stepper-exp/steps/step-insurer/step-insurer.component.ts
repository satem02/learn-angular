import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-step-insurer',
  templateUrl: './step-insurer.component.html',
  styleUrls: ['./step-insurer.component.scss']
})
export class StepInsurerComponent implements OnInit {
  InsurerFormGroup: FormGroup;

  constructor(private formBuilder: FormBuilder) {}

  ngOnInit() {
    this.InsurerFormGroup = this.formBuilder.group({
      address: ['', Validators.required]
    });
 } 
}