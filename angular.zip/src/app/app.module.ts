import { HttpClient, HttpClientModule } from "@angular/common/http";
import { BrowserModule } from "@angular/platform-browser";
import { CdkTableModule } from "@angular/cdk/table";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { platformBrowserDynamic } from "@angular/platform-browser-dynamic";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";

import { TranslateModule, TranslateLoader } from "@ngx-translate/core";
import { TranslateHttpLoader } from "@ngx-translate/http-loader";

import { CustomNdbxModule } from "./modules/ndbx-module";

import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { NavigationStepComponent } from "./components/navigation-step/navigation-step.component";
import { STEPPER_GLOBAL_OPTIONS } from "@angular/cdk/stepper";
import { StoreModule } from "@ngrx/store";
import { EffectsModule } from "@ngrx/effects";
import { ApiService } from "./services/core/api-service";
import { environment } from "src/environments/environment";
import { StoreDevtoolsModule } from "@ngrx/store-devtools";
import { LogPublishersService } from "./services/core/log/log-publishers-service";
import { LogEngineService } from "./services/core/log/log-engine.service";
import { DashboardMainComponent } from "./components/dashboard/dashboard-main/dashboard-main.component";
import { AgencyComponent } from "./components/common/agency/agency.component";
import { DynamicFormService } from "./services/core/dynamic-form/dynamic-form.service";
import { CustomDatePickerComponent } from "./components/common/custom-date-picker/custom-date-picker.component";
import { Pension2uDataService } from "./services/pension2u-data.service";
import { ConfirmationDialogModule } from "./components/common/confirmation-dialog/confirmation-dialog.module";
import { AgencyRequiredDirective } from "./components/common/agency/agency-required-directive";
import {
  StepProposalInformationComponent,
  StepInsuredComponent,
  StepInsurerComponent,
  StepBeneficiaryComponent,
  StepPlansFundsComponent,
  StepPaymentComponent,
  StepSummaryComponent
} from "./components/steps";
import {
  Pension2uFacade,
  Pension2uService,
  pension2uReducer,
  Pension2uEffects
} from "./+state";
import { AddressModule } from "./components/common/address/address.module";
import { EducationOccupationalModule } from "./components/common/education-occupational/education-occupational.module";
import { ContactModule } from "./components/common/contact/contact.module";
import { ConstantsService } from "./services/core/constants/constants.service";
import { FatcaModule } from "./components/common/fatca/fatca.module";
import { AppConstants } from "./models/common/app-constants";
import { OrderModule } from "ngx-order-pipe";

import {  NX_DATE_LOCALE } from '@allianz/ngx-ndbx/datefield'

export function translateHttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http, "./assets/i18n/", ".json");
}

export const PROVIDERS = [
  ApiService,
  LogEngineService,
  LogPublishersService,
  DynamicFormService,
  Pension2uDataService,
  ConstantsService,
  {
    provide: Pension2uFacade,
    useClass: Pension2uFacade
  },
  {
    provide: Pension2uService,
    useClass: Pension2uService
  },
  {
    provide: "environment.apiURL",
    useValue: environment.apiURL
  },
  {
    provide: "environment.logLevel",
    useValue: environment.logLevel
  },
  {
    provide: AppConstants,
    useValue: AppConstants
  },
  { provide: NX_DATE_LOCALE, useValue: "tr" }
];

@NgModule({
  imports: [
    HttpClientModule,
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    StoreModule.forRoot({}),
    StoreModule.forFeature("pension2u", pension2uReducer),
    EffectsModule.forRoot([Pension2uEffects]),
    StoreDevtoolsModule.instrument(),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: translateHttpLoaderFactory,
        deps: [HttpClient]
      }
    }),
    OrderModule,
    CdkTableModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    CustomNdbxModule,
    ConfirmationDialogModule,
    AddressModule,
    EducationOccupationalModule,
    ContactModule,
    FatcaModule
  ],
  declarations: [
    AppComponent,
    NavigationStepComponent,
    StepProposalInformationComponent,
    StepInsuredComponent,
    StepInsurerComponent,
    StepBeneficiaryComponent,
    StepPlansFundsComponent,
    StepPaymentComponent,
    StepSummaryComponent,
    DashboardMainComponent,
    AgencyComponent,
    CustomDatePickerComponent,
    AgencyRequiredDirective
  ],
  providers: [
    {
      provide: STEPPER_GLOBAL_OPTIONS,
      useValue: { showError: true }
    },
    PROVIDERS
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}

platformBrowserDynamic().bootstrapModule(AppModule);
