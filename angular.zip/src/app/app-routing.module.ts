import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NavigationStepComponent } from './components/navigation-step/navigation-step.component';
import { DashboardMainComponent } from './components/dashboard/dashboard-main/dashboard-main.component';

const routes: Routes = [
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: 'dashboard', component: DashboardMainComponent },
  { path: 'main/:customerTCKN', component: NavigationStepComponent },
  { path: '**', redirectTo: 'dashboard' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }