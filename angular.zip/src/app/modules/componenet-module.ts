import { NgModule } from '@angular/core';
import { NavigationStepComponent } from '../components/navigation-step/navigation-step.component';
import { StepInsuredComponent } from '../components/steps/step-insured/step-insured.component';
import { StepProposalInformationComponent } from '../components/steps/step-proposal-information/step-proposal-information.component';

@NgModule({
    exports: [
        NavigationStepComponent,
        StepProposalInformationComponent,
        StepInsuredComponent
    ]
})
export class CustomComponenetModule { }
