import { NgModule } from '@angular/core';
import { NxHeaderModule } from "@allianz/ngx-ndbx/header";
import { NxInputModule } from "@allianz/ngx-ndbx/input";
import { NxFooterModule } from "@allianz/ngx-ndbx/footer";
import { NxFormfieldModule } from '@allianz/ngx-ndbx/formfield';
import { NxIconModule } from "@allianz/ngx-ndbx/icon";
import { NxGridModule } from "@allianz/ngx-ndbx/grid";
import { NxTableModule } from "@allianz/ngx-ndbx/table";
import { NxBadgeModule } from "@allianz/ngx-ndbx/badge";
import { NxMomentDateModule } from "@allianz/ngx-ndbx/moment-date-adapter";
import { NxProgressStepperModule } from '@allianz/ngx-ndbx/progress-stepper';
import { NxDatefieldModule } from '@allianz/ngx-ndbx/datefield';



import {
    NxAutocompleteModule,
    NxAccordionModule,
    NxButtonModule,
    NxCheckboxModule,
    NxDropdownModule,
    NxDynamicTableModule,
    NxLinkModule,
    NxRadioModule,
    NxMessageModule,
    NxModalModule,
    NxPopoverModule,
    NxPageSearchModule,NxSpinnerModule
} from "@allianz/ngx-ndbx";

@NgModule({
    exports: [
        NxHeaderModule, NxMomentDateModule,
        NxInputModule,
        NxFormfieldModule,
        NxMessageModule,
        NxFooterModule,
        NxPopoverModule,
        NxCheckboxModule,
        NxDropdownModule,
        NxAutocompleteModule,
        NxAccordionModule,
        NxDynamicTableModule,
        NxRadioModule,
        NxTableModule,
        NxModalModule,
        NxIconModule,
        NxGridModule,
        NxBadgeModule,
        NxPageSearchModule,NxDatefieldModule,
        NxLinkModule,NxProgressStepperModule,
        NxButtonModule,NxSpinnerModule]
})


export class CustomNdbxModule { }