import { Component } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Moment } from 'moment';
import { NxDateAdapter } from '@allianz/ngx-ndbx/datefield';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

export class AppComponent {
  title = 'Pension';
  
  constructor(private translateService: TranslateService,
    private nxDateAdapter: NxDateAdapter<Moment>) {
    translateService.addLangs(['en', 'tr']);
    translateService.setDefaultLang('tr');
    this.nxDateAdapter.setLocale('tr');   
  }
}
