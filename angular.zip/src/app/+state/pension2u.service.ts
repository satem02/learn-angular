import { Injectable } from "@angular/core";
import { Observable } from "rxjs/internal/Observable";
import { map, tap } from "rxjs/operators";
import {
  PhoneContractResponse,
  PhoneContractRequest,
  CompanyInfoRequest,
  CompanyInfo,
  GenericResponseType,
  ProductInfoRequest,
  ProductInfo,
  CustomerInfoRequest,
  CustomerInfo,
  AgencyInfoRequest,
  AgencyInfo,
  ContractInfo,
  LookupInfoRequest,
  LookupInfo,
  AddressInfoRequest,
  AddressInfo
} from "../models/service";
import { ApiService } from "../services/core/api-service";
import { JobTypeInfo } from "../models/service/job-type-info/job-type-info";
import { EducationInfo } from "../models/service/education-info/education-info";
import { IncomeLevelInfo } from "../models/service/income-level-info/income-level-info";
import { CountryInfo } from "../models/service/country-info/country-info";
import { CountryInfoRequest } from "../models/service/country-info/country-info-request";
import { ProvinceInfo } from "../models/service/province-info/province-info";
import { ProvinceInfoRequest } from "../models/service/province-info/province-info-request";

@Injectable()
export class Pension2uService {
  readonly baseURL = "rest/";
  readonly companyUriBase = this.baseURL + "CompanyTypeService";
  readonly productUriBase = this.baseURL + "ProductTypeService";
  readonly agencyUriBase = this.baseURL + "AgencyTypeService";
  readonly customerTypeUriBase = this.baseURL + "CustomerTypeService"; //getCustomerTypeById
  readonly contractUriBase = this.baseURL + "ContractTypesService";
  readonly addressContractUriBase = this.baseURL + "AddressTypeService";
  readonly addressResidenteContractUriBase =
    this.baseURL + "CrsAddressTypeService";
  readonly kpsAddressContractUriBase = this.baseURL + "KpsService";
  readonly jobUriBase = this.baseURL + "JobTypeService";
  readonly educationUriBase = this.baseURL + "EducationTypeService";
  readonly incomeLevelTypeUriBase = this.baseURL + "IncomeLevelTypeService";
  readonly countryCityUriBase = this.baseURL + "CountryCityTypeService";
  readonly contactTypeUriBase = this.baseURL + "CommunicationTypeService";
  readonly lookupTypeUriBase = this.baseURL + "LookupTypeService";

  constructor(private apiService: ApiService) {}

  loadCompanies(input: CompanyInfoRequest): Observable<CompanyInfo[]> {
    return this.apiService
      .post(`${this.companyUriBase}/getCompanyTypeByTckn`, input)
      .pipe(map((response: GenericResponseType<any>) => response.dataOutput));
  }

  loadProducts(input: ProductInfoRequest): Observable<ProductInfo[]> {
    return this.apiService
      .post(`${this.productUriBase}/getProductTypeById`, input)
      .pipe(map((response: GenericResponseType<any>) => response.dataOutput));
  }

  loadCustomerInfo(input: CustomerInfoRequest): Observable<CustomerInfo> {
    return this.apiService
      .post(`${this.customerTypeUriBase}/getCustomerTypeById`, input)
      .pipe(
        map((response: GenericResponseType<any>) => response.dataOutput[0])
      );
  }

  loadAgencies(input: AgencyInfoRequest): Observable<AgencyInfo[]> {
    return this.apiService
      .post(`${this.agencyUriBase}/getAgencyTypeById`, input)
      .pipe(map((response: GenericResponseType<any>) => response.dataOutput));
  }

  loadContracts(): Observable<ContractInfo[]> {
    return this.apiService
      .post(`${this.contractUriBase}/getContractTypes`)
      .pipe(map((response: GenericResponseType<any>) => response.dataOutput));
  }

  loadAddressContractInfos(
    input: AddressInfoRequest
  ): Observable<AddressInfo[]> {
    return this.apiService
      .post(
        `${this.addressContractUriBase}/getAddressTypeByTcknAndCompanyId`,
        input
      )
      .pipe(map((response: GenericResponseType<any>) => response.dataOutput));
  }

  loadResidenceAddressInfos(
    input: AddressInfoRequest
  ): Observable<AddressInfo[]> {
    return this.apiService
      .post(`${this.kpsAddressContractUriBase}/queryAddress`, input)
      .pipe(map((response: GenericResponseType<any>) => response.dataOutput));
  }

  loadResidenteAddressInfos(
    input: AddressInfoRequest
  ): Observable<AddressInfo[]> {
    return this.apiService
      .post(
        `${this.addressResidenteContractUriBase}/getCrsAddressTypeByTcknAndCompanyId`,
        input
      )
      .pipe(map((response: GenericResponseType<any>) => response.dataOutput));
  }

  loadJobs(): Observable<JobTypeInfo[]> {
    return this.apiService
      .post(`${this.jobUriBase}/getJobTypes`)
      .pipe(map((response: GenericResponseType<any>) => response.dataOutput));
  }

  loadEducations(): Observable<EducationInfo[]> {
    return this.apiService
      .post(`${this.educationUriBase}/getEducationTypes`)
      .pipe(map((response: GenericResponseType<any>) => response.dataOutput));
  }

  loadIncomeLevels(): Observable<IncomeLevelInfo[]> {
    return this.apiService
      .post(`${this.incomeLevelTypeUriBase}/getIncomeLevelTypes`)
      .pipe(map((response: GenericResponseType<any>) => response.dataOutput));
  }

  loadCountries(): Observable<CountryInfo[]> {
    return this.apiService
      .post(
        `${this.countryCityUriBase}/getCountryCityTypeById`,
        new CountryInfoRequest()
      )
      .pipe(map((response: GenericResponseType<any>) => response.dataOutput));
  }

  loadProvinces(): Observable<ProvinceInfo[]> {
    return this.apiService
      .post(
        `${this.countryCityUriBase}/getCountryCityTypeById`,
        new ProvinceInfoRequest()
      )
      .pipe(map((response: GenericResponseType<any>) => response.dataOutput));
  }

  loadContactType(
    input: PhoneContractRequest
  ): Observable<PhoneContractResponse> {
    return this.apiService
      .post(`${this.contactTypeUriBase}/getCommunicationTypeById`, input)
      .pipe(map((response: GenericResponseType<any>) => response.dataOutput));
  }

  loadCountryPhoneCodes(input: LookupInfoRequest): Observable<LookupInfo[]> {
    return this.apiService
      .post(`${this.lookupTypeUriBase}/getCountryPhoneCodes`, input)
      .pipe(map((response: GenericResponseType<any>) => response.dataOutput));
  }
}
