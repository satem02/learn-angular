import { createFeatureSelector, createSelector } from '@ngrx/store';
import { Pension2uState } from './pension2u.reducer';

const getPension2uState = createFeatureSelector<Pension2uState>('pension2u');

export const getCompanyList = createSelector(getPension2uState, (state: Pension2uState) => state.companyList);
export const getProductList = createSelector(getPension2uState, (state: Pension2uState) => state.productList);
export const loadCustomerInfo = createSelector(getPension2uState, (state: Pension2uState) => state.customerInfo);
export const getAgencyList = createSelector(getPension2uState, (state: Pension2uState) => state.agencyList);
export const getContractList = createSelector(getPension2uState, (state: Pension2uState) => state.contractList);
export const getAddressContractInfoList = createSelector(getPension2uState, (state: Pension2uState) => state.addressContractInfoList);
export const getResidenceAddressContractList = createSelector(getPension2uState, (state: Pension2uState) => state.residenceAddressContractList);
export const getResidenteAddressContractList = createSelector(getPension2uState, (state: Pension2uState) => state.residenteAddressContractList);
export const getJobList = createSelector(getPension2uState, (state: Pension2uState) => state.jobList);
export const getEducationList = createSelector(getPension2uState, (state: Pension2uState) => state.educationList);
export const getIncomeLevelList = createSelector(getPension2uState, (state: Pension2uState) => state.incomeLevelList);
export const setProposalInformation= createSelector(getPension2uState, (state: Pension2uState) => state.proposalInformation);
export const setInsuredDetail= createSelector(getPension2uState, (state: Pension2uState) => state.insuredDetail);
export const setInsurerDetail= createSelector(getPension2uState, (state: Pension2uState) => state.insurerDetail);
export const setPlansFunds= createSelector(getPension2uState, (state: Pension2uState) => state.plansFunds);
export const setPaymentDetail= createSelector(getPension2uState, (state: Pension2uState) => state.paymentDetail);
export const getCountryList= createSelector(getPension2uState, (state: Pension2uState) => state.countryList);
export const getProvinceList = createSelector(getPension2uState, (state: Pension2uState) => state.provinceList);
export const getContactType = createSelector(getPension2uState, (state: Pension2uState) => state.contactType);
export const getCountryCodeList = createSelector(getPension2uState, (state: Pension2uState) => state.countryCodeList);


export const pension2uStateQuery = {
    getCompanyList: getCompanyList,
    getProductList: getProductList,
    getAgencyList: getAgencyList,
    getContractList: getContractList,
    loadCustomerInfo: loadCustomerInfo,
    getAddressContractInfoList: getAddressContractInfoList,
    getResidenceAddressContractList: getResidenceAddressContractList,
    getResidenteAddressContractList: getResidenteAddressContractList,
    getJobList:getJobList,
    getEducationList:getEducationList,
    getIncomeLevelList:getIncomeLevelList,
    setProposalInformation:setProposalInformation,
    setInsuredDetail:setInsuredDetail,
    setInsurerDetail:setInsurerDetail,
    setPlansFunds:setPlansFunds,
    setPaymentDetail:setPaymentDetail,
    getCountryList:getCountryList,
    getProvinceList:getProvinceList,
    getContactType:getContactType,
    getCountryCodeList:getCountryCodeList
}
