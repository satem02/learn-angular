import { Actions, createEffect, ofType } from "@ngrx/effects";
import { Store } from "@ngrx/store";
import * as stateActions from "./pension2u.action";
import { Pension2uService } from "./pension2u.service";
import { Injectable } from "@angular/core";
import { of } from "rxjs/internal/observable/of";
import { catchError, concatMap, map } from "rxjs/operators";

@Injectable()
export class Pension2uEffects {
  loadCompanies = createEffect(() =>
    this.actions$.pipe(
      ofType(stateActions.loadCompanies),
      concatMap(action =>
        this.pension2uService.loadCompanies(action.input).pipe(
          map(results =>
            stateActions.loadCompaniesLoaded({ companyList: results })
          ),
          catchError((error: Error) =>
            of(stateActions.loadCompaniesLoadFail({ error: error }))
          )
        )
      )
    )
  );

  loadProducts = createEffect(() =>
    this.actions$.pipe(
      ofType(stateActions.loadProducts),
      concatMap(action =>
        this.pension2uService.loadProducts(action.input).pipe(
          map(results =>
            stateActions.loadProductsLoaded({ productList: results })
          ),
          catchError((error: Error) =>
            of(stateActions.loadProductsLoadFail({ error: error }))
          )
        )
      )
    )
  );

  loadCustomerInfo = createEffect(() =>
    this.actions$.pipe(
      ofType(stateActions.loadCustomerInfo),
      concatMap(action =>
        this.pension2uService.loadCustomerInfo(action.input).pipe(
          map(result =>
            stateActions.loadCustomerInfoLoaded({ customerInfo: result })
          ),
          catchError((error: Error) =>
            of(stateActions.loadCustomerInfoLoadFail({ error: error }))
          )
        )
      )
    )
  );

  loadAgencies = createEffect(() =>
    this.actions$.pipe(
      ofType(stateActions.loadAgencies),
      concatMap(action =>
        this.pension2uService.loadAgencies(action.input).pipe(
          map(results =>
            stateActions.loadAgenciesLoaded({ agencyList: results })
          ),
          catchError((error: Error) =>
            of(stateActions.loadProductsLoadFail({ error: error }))
          )
        )
      )
    )
  );

  loadContracts = createEffect(() =>
    this.actions$.pipe(
      ofType(stateActions.loadContracts),
      concatMap(action =>
        this.pension2uService.loadContracts().pipe(
          map(results =>
            stateActions.loadContractsLoaded({ contractList: results })
          ),
          catchError((error: Error) =>
            of(stateActions.loadContractsLoadFail({ error: error }))
          )
        )
      )
    )
  );

  loadResidenceAddressContractInfos = createEffect(() =>
    this.actions$.pipe(
      ofType(stateActions.loadAddressResidenceContracts),
      concatMap(action =>
        this.pension2uService.loadResidenceAddressInfos(action.input).pipe(
          map(results =>
            stateActions.loadAddressResidenceContractsLoaded({
              residenceList: results
            })
          ),
          catchError((error: Error) =>
            of(
              stateActions.loadAddressResidenceContractsLoadFail({
                error: error
              })
            )
          )
        )
      )
    )
  );

  loadResidenteAddressContractInfos = createEffect(() =>
    this.actions$.pipe(
      ofType(stateActions.loadAddressResidenteContracts),
      concatMap(action =>
        this.pension2uService.loadResidenteAddressInfos(action.input).pipe(
          map(results =>
            stateActions.loadAddressResidenteContractsLoaded({
              residenteList: results
            })
          ),
          catchError((error: Error) =>
            of(
              stateActions.loadAddressResidenteContractsLoadFail({
                error: error
              })
            )
          )
        )
      )
    )
  );

  loadAddressContractInfos = createEffect(() =>
    this.actions$.pipe(
      ofType(stateActions.loadAddressInfoContracts),
      concatMap(action =>
        this.pension2uService.loadAddressContractInfos(action.input).pipe(
          map(results =>
            stateActions.loadAddressInfoContractsLoaded({
              contractList: results
            })
          ),
          catchError((error: Error) =>
            of(stateActions.loadAddressInfoContractsLoadFail({ error: error }))
          )
        )
      )
    )
  );

  loadJobs = createEffect(() =>
    this.actions$.pipe(
      ofType(stateActions.loadJobs),
      concatMap(action =>
        this.pension2uService.loadJobs().pipe(
          map(results => stateActions.loadJobsLoaded({ jobList: results })),
          catchError((error: Error) =>
            of(stateActions.loadJobsLoadFail({ error: error }))
          )
        )
      )
    )
  );

  loadEducations = createEffect(() =>
    this.actions$.pipe(
      ofType(stateActions.loadEducations),
      concatMap(action =>
        this.pension2uService.loadEducations().pipe(
          map(results =>
            stateActions.loadEducationsLoaded({ educationList: results })
          ),
          catchError((error: Error) =>
            of(stateActions.loadEducationsLoadFail({ error: error }))
          )
        )
      )
    )
  );

  loadIncomeLevels = createEffect(() =>
    this.actions$.pipe(
      ofType(stateActions.loadIncomeLevels),
      concatMap(action =>
        this.pension2uService.loadIncomeLevels().pipe(
          map(results =>
            stateActions.loadIncomeLevelsLoaded({ incomeLevelList: results })
          ),
          catchError((error: Error) =>
            of(stateActions.loadIncomeLevelsLoadFail({ error: error }))
          )
        )
      )
    )
  );

  loadCountries = createEffect(() =>
    this.actions$.pipe(
      ofType(stateActions.loadCountries),
      concatMap(action =>
        this.pension2uService.loadCountries().pipe(
          map(results =>
            stateActions.loadCountriesLoaded({ countryList: results })
          ),
          catchError((error: Error) =>
            of(stateActions.loadCountriesLoadFail({ error: error }))
          )
        )
      )
    )
  );

  loadProvinces = createEffect(() =>
    this.actions$.pipe(
      ofType(stateActions.loadProvinces),
      concatMap(action =>
        this.pension2uService.loadProvinces().pipe(
          map(results =>
            stateActions.loadProvincesLoaded({ provinceList: results })
          ),
          catchError((error: Error) =>
            of(stateActions.loadProvincesLoadFail({ error: error }))
          )
        )
      )
    )
  );

  loadContactType = createEffect(() =>
    this.actions$.pipe(
      ofType(stateActions.loadContactType),
      concatMap(action =>
        this.pension2uService.loadContactType(action.input).pipe(
          map(results =>
            stateActions.loadContactTypeLoaded({ contactType: results })
          ),
          catchError((error: Error) =>
            of(stateActions.loadContactTypeLoadFail({ error: error }))
          )
        )
      )
    )
  );

  loadCountryPhoneCodes = createEffect(() =>
    this.actions$.pipe(
      ofType(stateActions.loadCountryPhoneCodes),
      concatMap(action =>
        this.pension2uService.loadCountryPhoneCodes(action.input).pipe(
          map(results =>
            stateActions.loadCountryPhoneCodesLoaded({
              countryCodeList: results
            })
          ),
          catchError((error: Error) =>
            of(stateActions.loadCountryPhoneCodesLoadFail({ error: error }))
          )
        )
      )
    )
  );

  constructor(
    private actions$: Actions,
    private store: Store<any>,
    private pension2uService: Pension2uService
  ) {}
}
