import { Action, createReducer, on } from "@ngrx/store";
import {
  loadCompaniesLoaded,
  loadProductsLoaded,
  loadCustomerInfoLoaded,
  loadAgenciesLoaded,
  loadContractsLoaded,
  loadAddressInfoContractsLoaded,
  loadJobsLoaded,
  loadEducationsLoaded,
  loadIncomeLevelsLoaded,
  setProposalInformation,
  loadAddressResidenceContractsLoaded,
  loadAddressResidenteContractsLoaded,
  loadCountriesLoaded,
  loadProvincesLoaded,
  loadContactTypeLoaded,
  loadCountryPhoneCodesLoaded,
  setInsuredDetail,
  setPlansFunds,
  setPaymentDetail,
  setInsurerDetail
} from "./pension2u.action";
import { CustomerInfo } from "../models/service/customer-info/customer-info";
import { CompanyInfo } from "../models/service/company-info/company-info";
import { ProductInfo } from "../models/service/product-info/product-info";
import { AgencyInfo } from "../models/service/agency-info/agency-info";
import { ContractInfo } from "../models/service/contract-info/contract-info";
import { AddressInfo } from "../models/service/address-info/address-info";
import { JobTypeInfo } from "../models/service/job-type-info/job-type-info";
import { EducationInfo } from "../models/service/education-info/education-info";
import { IncomeLevelInfo } from "../models/service/income-level-info/income-level-info";
import { ProposalInformationDTO, InsuredDetailDTO, PlansFundsDTO, PaymentInfoDTO } from "../models/step";
import { CountryInfo } from "../models/service/country-info/country-info";
import { ProvinceInfo } from "../models/service/province-info/province-info";
import { PhoneContractResponse, LookupInfo } from "../models/service";
import { InsurerDetailDTO } from '../models/step/step-insurer-information';

export interface Pension2uState {
  companyList: CompanyInfo[];
  productList: ProductInfo[];
  agencyList: AgencyInfo[];
  customerInfo: CustomerInfo;
  contractList: ContractInfo[];
  addressContractInfoList: AddressInfo[];
  residenceAddressContractList: AddressInfo[];
  residenteAddressContractList: AddressInfo[];
  jobList: JobTypeInfo[];
  educationList: EducationInfo[];
  incomeLevelList: IncomeLevelInfo[];
  proposalInformation: ProposalInformationDTO;
  insuredDetail: InsuredDetailDTO;
  insurerDetail: InsurerDetailDTO;
  plansFunds: PlansFundsDTO;
  paymentDetail: PaymentInfoDTO;
  countryList: CountryInfo[];
  provinceList: ProvinceInfo[];
  contactType: PhoneContractResponse;
  countryCodeList : LookupInfo[];
}

export const pension2uStateInitialState: Pension2uState = {
  companyList: [],
  productList: [],
  agencyList: [],
  contractList: [],
  customerInfo: new CustomerInfo(),
  addressContractInfoList: [],
  residenceAddressContractList: [],
  residenteAddressContractList: [],
  jobList: [],
  educationList: [],
  incomeLevelList: [],
  proposalInformation: new ProposalInformationDTO(),
  insuredDetail:new InsuredDetailDTO(),
  insurerDetail:new InsurerDetailDTO(),
  plansFunds:new PlansFundsDTO(),
  paymentDetail:new PaymentInfoDTO(),
  countryList: [],
  provinceList: [],
  contactType: new PhoneContractResponse(),
  countryCodeList:[]
};

export const reducer = createReducer(
  pension2uStateInitialState,
  on(loadCompaniesLoaded, (state, payload) => ({
    ...state,
    companyList: payload.companyList
  })),
  on(loadProductsLoaded, (state, payload) => ({
    ...state,
    productList: payload.productList
  })),
  on(loadCustomerInfoLoaded, (state, payload) => ({
    ...state,
    customerInfo: payload.customerInfo
  })),
  on(loadAgenciesLoaded, (state, payload) => ({
    ...state,
    agencyList: payload.agencyList
  })),
  on(loadContractsLoaded, (state, payload) => ({
    ...state,
    contractList: payload.contractList
  })),
  on(loadAddressInfoContractsLoaded, (state, payload) => ({
    ...state,
    addressContractInfoList: payload.contractList
  })),
  on(loadAddressResidenceContractsLoaded, (state, payload) => ({
    ...state,
    residenceAddressContractList: payload.residenceList
  })),
  on(loadAddressResidenteContractsLoaded, (state, payload) => ({
    ...state,
    residenteAddressContractList: payload.residenteList
  })),
  on(loadJobsLoaded, (state, payload) => ({
    ...state,
    jobList: payload.jobList
  })),
  on(loadEducationsLoaded, (state, payload) => ({
    ...state,
    educationList: payload.educationList
  })),
  on(loadIncomeLevelsLoaded, (state, payload) => ({
    ...state,
    incomeLevelList: payload.incomeLevelList
  })),
  on(setProposalInformation, (state, payload) => ({
    ...state,
    proposalInformation: payload.proposalInformation
  })),  
  on(setInsuredDetail, (state, payload) => ({
    ...state,
    insuredDetail: payload.insuredDetail
  })),    
  on(setInsurerDetail, (state, payload) => ({
    ...state,
    insurerDetail: payload.insurerDetail
  })), 
  on(setPlansFunds, (state, payload) => ({
    ...state,
    plansFunds: payload.plansFunds
  })),  
  on(setPaymentDetail, (state, payload) => ({
    ...state,
    paymentDetail: payload.paymentDetail
  })),
  on(loadCountriesLoaded, (state, payload) => ({
    ...state,
    countryList: payload.countryList
  })),
  on(loadProvincesLoaded, (state, payload) => ({
    ...state,
    provinceList: payload.provinceList
  })),
  on(loadContactTypeLoaded, (state, payload) => ({
    ...state,
    contactType: payload.contactType
  })),
  on(loadCountryPhoneCodesLoaded, (state, payload) => ({
    ...state,
    countryCodeList: payload.countryCodeList
  }))
);

export function pension2uReducer(
  state: Pension2uState | undefined,
  action: Action
) {
  return reducer(state, action);
}
