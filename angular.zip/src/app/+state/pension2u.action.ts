import { createAction, props } from '@ngrx/store';
import { CustomerInfo } from '../models/service/customer-info/customer-info';
import { CustomerInfoRequest } from '../models/service/customer-info/customer-info-request';
import { CompanyInfoRequest } from '../models/service/company-info/company-info-request';
import { ProductInfo } from '../models/service/product-info/product-info';
import { CompanyInfo } from '../models/service/company-info/company-info';
import { ProductInfoRequest } from '../models/service/product-info/product-info-request';
import { AgencyInfoRequest } from '../models/service/agency-info/agency-info-request';
import { AgencyInfo } from '../models/service/agency-info/agency-info';
import { ContractInfo } from '../models/service/contract-info/contract-info';
import { AddressInfoRequest } from '../models/service/address-info/address-info-request';
import { AddressInfo } from '../models/service/address-info/address-info';
import { JobTypeInfo } from '../models/service/job-type-info/job-type-info';
import { EducationInfo } from '../models/service/education-info/education-info';
import { IncomeLevelInfo } from '../models/service/income-level-info/income-level-info';
import { ProposalInformationDTO, InsuredDetailDTO, PlansFundsDTO, PaymentInfoDTO } from '../models/step';
import { CountryInfo } from '../models/service/country-info/country-info';
import { ProvinceInfo } from '../models/service/province-info/province-info';
import { PhoneContractRequest, PhoneContractResponse, LookupInfoRequest, LookupInfo } from '../models/service';
import { InsurerDetailDTO } from '../models/step/step-insurer-information';

export const loadCompanies = createAction('[Pension2 Company] Load Companies', props<{ input: CompanyInfoRequest }>());
export const loadCompaniesLoaded = createAction('[Pension2 Company] Companies Loaded', props<{ companyList: CompanyInfo[] }>());
export const loadCompaniesLoadFail = createAction('[Pension2 Company] Companies Failed', props<{ error: Error }>());

export const loadProducts = createAction('[Pension2 Company] Load Products', props<{ input: ProductInfoRequest }>());
export const loadProductsLoaded = createAction('[Pension2 Company] Products Loaded', props<{ productList: ProductInfo[] }>());
export const loadProductsLoadFail = createAction('[Pension2 Company] Products Failed', props<{ error: Error }>());

export const loadCustomerInfo = createAction('[Pension2 CustomerInfo] Load CustomerInfo', props<{ input: CustomerInfoRequest }>());
export const loadCustomerInfoLoaded = createAction('[Pension2 CustomerInfo] CustomerInfo Loaded', props<{ customerInfo: CustomerInfo }>());
export const loadCustomerInfoLoadFail = createAction('[Pension2 CustomerInfo] CustomerInfo Failed', props<{ error: Error }>());

export const loadAgencies = createAction('[Pension2 Agency] Load Agencies', props<{ input: AgencyInfoRequest }>());
export const loadAgenciesLoaded = createAction('[Pension2 Agency] Agencies Loaded', props<{ agencyList: AgencyInfo[] }>());
export const loadAgenciesLoadFail = createAction('[Pension2 Agency] Agencies Failed', props<{ error: Error }>());

export const loadContracts = createAction('[Pension2 Contracts] Load Contracts', props<{ }>());
export const loadContractsLoaded = createAction('[Pension2 Contracts] Contracts Loaded', props<{ contractList: ContractInfo[] }>());
export const loadContractsLoadFail = createAction('[Pension2 Contracts] Contracts Failed', props<{ error: Error }>());

export const loadAddressInfoContracts = createAction('[Pension2 Address Info Contracts] Load Address', props<{input: AddressInfoRequest }>());
export const loadAddressInfoContractsLoaded = createAction('[Pension2 Address Info Contracts] Address Loaded', props<{ contractList: AddressInfo[] }>());
export const loadAddressInfoContractsLoadFail = createAction('[Pension2 Address Info Contracts] Address Failed', props<{ error: Error }>());

export const loadAddressResidenceContracts = createAction('[Pension2 Address Residence Contracts] Load Address', props<{input: AddressInfoRequest }>());
export const loadAddressResidenceContractsLoaded = createAction('[Pension2 Address Residence Contracts] Address Loaded', props<{ residenceList: AddressInfo[] }>());
export const loadAddressResidenceContractsLoadFail = createAction('[Pension2 Address Residence Contracts] Address Failed', props<{ error: Error }>());

export const loadAddressResidenteContracts = createAction('[Pension2 Address Residente Contracts] Load Address', props<{input: AddressInfoRequest }>());
export const loadAddressResidenteContractsLoaded = createAction('[Pension2 Address Residente Contracts] Address Loaded', props<{ residenteList: AddressInfo[] }>());
export const loadAddressResidenteContractsLoadFail = createAction('[Pension2 Address Residente Contracts] Address Failed', props<{ error: Error }>());

export const loadJobs = createAction('[Pension2 Jobs] Load Jobs', props<{ }>());
export const loadJobsLoaded = createAction('[Pension2 Jobs] Jobs Loaded', props<{ jobList: JobTypeInfo[] }>());
export const loadJobsLoadFail = createAction('[Pension2 Jobs] Jobs Failed', props<{ error: Error }>());

export const loadEducations = createAction('[Pension2 Educations] Load Educations', props<{ }>());
export const loadEducationsLoaded = createAction('[Pension2 Educations] Educations Loaded', props<{ educationList: EducationInfo[] }>());
export const loadEducationsLoadFail = createAction('[Pension2 Educations] Educations Failed', props<{ error: Error }>());

export const loadIncomeLevels = createAction('[Pension2 IncomeLevels] Load IncomeLevels', props<{ }>());
export const loadIncomeLevelsLoaded = createAction('[Pension2 IncomeLevels] IncomeLevels Loaded', props<{ incomeLevelList: IncomeLevelInfo[] }>());
export const loadIncomeLevelsLoadFail = createAction('[Pension2 IncomeLevels] IncomeLevels Failed', props<{ error: Error }>());

export const setProposalInformation = createAction('[Pension2 Proposal Information] Proposal Information', props<{ proposalInformation: ProposalInformationDTO }>());
export const setInsuredDetail = createAction('[Pension2 Insured Detail] Insured Detail', props<{ insuredDetail: InsuredDetailDTO }>());
export const setInsurerDetail = createAction('[Pension2 Insurer Detail] Insurer Detail', props<{ insurerDetail: InsurerDetailDTO }>());
export const setPlansFunds = createAction('[Pension2 Plans Funds] Plans Funds', props<{ plansFunds: PlansFundsDTO }>());
export const setPaymentDetail = createAction('[Pension2 Payment Detail] Payment Detail', props<{ paymentDetail: PaymentInfoDTO }>());

export const loadCountries = createAction('[Pension2 Countries] Load Countries', props<{ }>());
export const loadCountriesLoaded = createAction('[Pension2 Countries] Countries Loaded', props<{ countryList: CountryInfo[] }>());
export const loadCountriesLoadFail = createAction('[Pension2 Countries] Countries Failed', props<{ error: Error }>());

export const loadProvinces = createAction('[Pension2 Provinces] Load Provinces', props<{ }>());
export const loadProvincesLoaded = createAction('[Pension2 Provinces] Provinces Loaded', props<{ provinceList: ProvinceInfo[] }>());
export const loadProvincesLoadFail = createAction('[Pension2 Provinces] Provinces Failed', props<{ error: Error }>());

export const loadContactType = createAction('[Pension2 Contract Type List] Load  Contract Type List', props<{ input:PhoneContractRequest }>());
export const loadContactTypeLoaded = createAction('[Pension2  Contract Type List]  Contract Type List Loaded', props<{ contactType: PhoneContractResponse }>());
export const loadContactTypeLoadFail = createAction('[Pension2  Contract Type List]  Contract Type List Failed', props<{ error: Error }>());

export const loadCountryPhoneCodes = createAction('[Pension2 Country Phone Codes] Load  Country Phone Codes', props<{ input:LookupInfoRequest }>());
export const loadCountryPhoneCodesLoaded = createAction('[Pension2  Country Phone Codes]  Country Phone Codes Loaded', props<{ countryCodeList: LookupInfo[] }>());
export const loadCountryPhoneCodesLoadFail = createAction('[Pension2  Country Phone Codes]  Country Phone Codes Failed', props<{ error: Error }>());


export const serviceError = createAction(
    '[article] LOAD_SERVICE_ERROR',
    props<{ error: Error }>()
);