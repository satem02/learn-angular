import { Injectable } from "@angular/core";
import { select, Store } from "@ngrx/store";
import { Observable } from "rxjs/internal/Observable";
import { Pension2uState } from "./pension2u.reducer";
import { pension2uStateQuery } from "./pension2u.selectors";
import * as rootActions from "./pension2u.action";
import { CustomerInfo } from "../models/service/customer-info/customer-info";
import { CustomerInfoRequest } from "../models/service/customer-info/customer-info-request";
import { CompanyInfoRequest } from "../models/service/company-info/company-info-request";
import { ProductInfoRequest } from "../models/service/product-info/product-info-request";
import { CompanyInfo } from "../models/service/company-info/company-info";
import { ProductInfo } from "../models/service/product-info/product-info";
import { AgencyInfo } from "../models/service/agency-info/agency-info";
import { AgencyInfoRequest } from "../models/service/agency-info/agency-info-request";
import { ContractInfo } from "../models/service/contract-info/contract-info";
import { AddressInfo } from "../models/service/address-info/address-info";
import { AddressInfoRequest } from "../models/service/address-info/address-info-request";
import { JobTypeInfo } from "../models/service/job-type-info/job-type-info";
import { EducationInfo } from "../models/service/education-info/education-info";
import { IncomeLevelInfo } from "../models/service/income-level-info/income-level-info";
import {
  ProposalInformationDTO,
  InsuredDetailDTO,
  PlansFundsDTO,
  PaymentInfoDTO
} from "../models/step";
import { ProvinceInfo } from "../models/service/province-info/province-info";
import { CountryInfo } from "../models/service/country-info/country-info";
import {
  PhoneContractResponse,
  PhoneContractRequest,
  LookupInfoRequest,
  LookupInfo
} from "../models/service";
import { InsurerDetailDTO } from '../models/step/step-insurer-information';

@Injectable({
  providedIn: "root"
})
export class Pension2uFacade {
  companyList$: Observable<CompanyInfo[]>;
  productList$: Observable<ProductInfo[]>;
  customerInfo$: Observable<CustomerInfo>;
  agencyList$: Observable<AgencyInfo[]>;
  contractList$: Observable<ContractInfo[]>;
  addressContractInfoList$: Observable<AddressInfo[]>;
  residenceAddressContractList$: Observable<AddressInfo[]>;
  residenteAddressContractList$: Observable<AddressInfo[]>;
  jobList$: Observable<JobTypeInfo[]>;
  educationList$: Observable<EducationInfo[]>;
  incomeLevelList$: Observable<IncomeLevelInfo[]>;
  proposalInformation$: Observable<ProposalInformationDTO>;
  insuredDetail$: Observable<InsuredDetailDTO>;
  insurerDetail$: Observable<InsurerDetailDTO>;
  plansFunds$: Observable<PlansFundsDTO>;
  paymentDetail$: Observable<PaymentInfoDTO>;
  countryList$: Observable<CountryInfo[]>;
  provinceList$: Observable<ProvinceInfo[]>;
  contactType$: Observable<PhoneContractResponse>;
  countryCodeList$: Observable<LookupInfo[]>;

  constructor(private store: Store<Pension2uState>) {
    this.companyList$ = store.pipe(select(pension2uStateQuery.getCompanyList));
    this.productList$ = store.pipe(select(pension2uStateQuery.getProductList));
    this.customerInfo$ = store.pipe(
      select(pension2uStateQuery.loadCustomerInfo)
    );
    this.agencyList$ = store.pipe(select(pension2uStateQuery.getAgencyList));
    this.contractList$ = store.pipe(
      select(pension2uStateQuery.getContractList)
    );
    this.addressContractInfoList$ = store.pipe(
      select(pension2uStateQuery.getAddressContractInfoList)
    );
    this.residenceAddressContractList$ = store.pipe(
      select(pension2uStateQuery.getResidenceAddressContractList)
    );
    this.residenteAddressContractList$ = store.pipe(
      select(pension2uStateQuery.getResidenteAddressContractList)
    );
    this.jobList$ = store.pipe(select(pension2uStateQuery.getJobList));
    this.educationList$ = store.pipe(
      select(pension2uStateQuery.getEducationList)
    );
    this.incomeLevelList$ = store.pipe(
      select(pension2uStateQuery.getIncomeLevelList)
    );
    this.proposalInformation$ = store.pipe(
      select(pension2uStateQuery.setProposalInformation)
    );
    this.insuredDetail$ = store.pipe(
      select(pension2uStateQuery.setInsuredDetail)
    );
    this.insurerDetail$ = store.pipe(
      select(pension2uStateQuery.setInsurerDetail)
    );
    this.plansFunds$ = store.pipe(select(pension2uStateQuery.setPlansFunds));
    this.paymentDetail$ = store.pipe(select(pension2uStateQuery.setPaymentDetail));
    this.countryList$ = store.pipe(select(pension2uStateQuery.getCountryList));
    this.provinceList$ = store.pipe(
      select(pension2uStateQuery.getProvinceList)
    );
    this.contactType$ = store.pipe(select(pension2uStateQuery.getContactType));
    this.countryCodeList$ = store.pipe(
      select(pension2uStateQuery.getCountryCodeList)
    );
  }

  loadCompanyList(input: CompanyInfoRequest) {
    this.store.dispatch(rootActions.loadCompanies({ input }));
  }

  loadProductsList(input: ProductInfoRequest) {
    this.store.dispatch(rootActions.loadProducts({ input }));
  }

  loadCustomerInfo(input: CustomerInfoRequest) {
    this.store.dispatch(rootActions.loadCustomerInfo({ input }));
  }

  loadAgencies(input: AgencyInfoRequest) {
    this.store.dispatch(rootActions.loadAgencies({ input }));
  }

  loadContractList() {
    this.store.dispatch(rootActions.loadContracts({}));
  }

  loadAddressContractInfoList(input: AddressInfoRequest) {
    this.store.dispatch(rootActions.loadAddressInfoContracts({ input }));
  }

  loadResidenceAddressInfoList(input: AddressInfoRequest) {
    this.store.dispatch(rootActions.loadAddressResidenceContracts({ input }));
  }

  loadResidenteAddressInfoList(input: AddressInfoRequest) {
    this.store.dispatch(rootActions.loadAddressResidenteContracts({ input }));
  }

  loadJobList() {
    this.store.dispatch(rootActions.loadJobs({}));
  }

  loadEducationList() {
    this.store.dispatch(rootActions.loadEducations({}));
  }

  loadIncomeLevelList() {
    this.store.dispatch(rootActions.loadIncomeLevels({}));
  }

  setProposalInformation(proposalInformation: ProposalInformationDTO) {
    this.store.dispatch(
      rootActions.setProposalInformation({ proposalInformation })
    );
  }

  setInsuredDetail(insuredDetail: InsuredDetailDTO) {
    this.store.dispatch(rootActions.setInsuredDetail({ insuredDetail }));
  }

  setInsurerDetail(insurerDetail: InsurerDetailDTO) {
    this.store.dispatch(rootActions.setInsurerDetail({ insurerDetail }));
  }

  setPlansFunds(plansFunds: PlansFundsDTO) {
    this.store.dispatch(rootActions.setPlansFunds({ plansFunds }));
  }

  setPaymentDetail(paymentDetail: PaymentInfoDTO) {
    this.store.dispatch(rootActions.setPaymentDetail({ paymentDetail }));
  }

  loadCountryList() {
    this.store.dispatch(rootActions.loadCountries({}));
  }

  loadProvinceList() {
    this.store.dispatch(rootActions.loadProvinces({}));
  }

  loadContactType(input: PhoneContractRequest) {
    this.store.dispatch(rootActions.loadContactType({ input }));
  }

  loadCountryPhoneCodes(input: LookupInfoRequest) {
    this.store.dispatch(rootActions.loadCountryPhoneCodes({ input }));
  }
}
