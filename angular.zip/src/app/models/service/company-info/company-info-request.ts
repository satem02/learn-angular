export class CompanyInfoRequest {
    public tckn: string;
    public companyCode:number;
  }
  