export class CompanyInfo {
    public companyId: number;
    public companyName: string;
  }