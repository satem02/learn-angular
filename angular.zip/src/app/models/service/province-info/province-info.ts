export class ProvinceInfo {
    public code: string;
    public name: string;
}
