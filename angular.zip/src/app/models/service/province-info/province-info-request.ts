export class ProvinceInfoRequest {
    public type: string = "I";
}