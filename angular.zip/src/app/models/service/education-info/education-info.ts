export class EducationInfo {
    educationCode: string;
    educationName: string;
}
