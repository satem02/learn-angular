export class ProductInfo {
    public productCode: number;
    public productName: string;
  }