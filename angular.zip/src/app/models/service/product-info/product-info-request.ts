export class ProductInfoRequest {
    public companyCode: number;
  }
  