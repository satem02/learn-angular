export class KPSInfoRequest {
  public rimNo: number;
  public idNo: number;
  public birthdate: Date;
  public fatherName: string;
  public isHeadquarterEmployee:boolean;
}
