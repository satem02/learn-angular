import { CreditCardNoInfo } from "../credit-card-no-info/credit-card-no-info";

export class KPSInfo {
  public identityNo: number;
  public gender: string;
  public name: string;
  public surname: string;
  public placeOfBirth: string;
  public dateOfBirth: string;
  public motherName: string;
  public fatherName: string;
  public nationatily: string;
  public sectorCode: string;
  public maritalStatus: string;
  public blueCardIssueDate: string;
  public ykbcustomerNo: string;
  public rpaAnswer: string;
  public rpaWarning: string;
  public creditCards: CreditCardNoInfo[];
}
