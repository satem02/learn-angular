export class SubGroupInfo {
  public subGroupCode: number;
  public subGroupName: string;
}