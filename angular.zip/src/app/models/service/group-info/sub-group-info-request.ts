export class SubGroupInfoRequest {
    public groupCode: number;
  }
  