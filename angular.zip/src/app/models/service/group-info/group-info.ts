export class GroupInfo {
  public groupCode: number;
  public groupName: string;
}