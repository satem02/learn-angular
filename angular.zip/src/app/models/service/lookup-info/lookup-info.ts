export class LookupInfo {
  public lookupType: string;
  public lookupCode: string;
  public lookupValue: string;
  public description: string;
}