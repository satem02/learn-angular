export class LookupInfoRequest {
}