export class JobTypeInfo {
    jobCode: string;
    jobName: string;
}
