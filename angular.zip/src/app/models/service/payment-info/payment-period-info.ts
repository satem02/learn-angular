export class PaymentPeriodInfo {
  public paymentPeriodCode: number;
  public paymentPeriodName: string;
}
