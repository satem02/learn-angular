export class PaymentTypeInfo {
  public paymentTypeCode: string;
  public paymentTypeName: string;
}