export class CreditCardNoInfo {
  public hiddenCreditCardNo: string;
  public productCode: string;
  public creditCardNo: string;
  public validityEndDate: string;
}
