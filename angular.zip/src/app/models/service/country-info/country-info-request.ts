export class CountryInfoRequest {
    public type: string = "U";
}