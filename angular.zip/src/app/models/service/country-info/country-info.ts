export class CountryInfo {
    public code: string;
    public name: string;
}
