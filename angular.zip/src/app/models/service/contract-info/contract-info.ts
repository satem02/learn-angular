export class ContractInfo {
    public company: number;
    public value: string;
    public description: string;
  }