export class DropdownDTO {
    public code: string;
    public displayText: string;
    public order: number;
    public isActive: boolean;
  }
  