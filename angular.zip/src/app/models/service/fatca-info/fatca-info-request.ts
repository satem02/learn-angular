export class FatcaInfoRequest {
}