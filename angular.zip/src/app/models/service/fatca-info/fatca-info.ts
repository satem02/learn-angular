import { CountryInfo } from '../country-info/country-info';
import { LookupInfo } from '../lookup-info/lookup-info';


export class FatcaInfo {
  public countryTaxpayer: CountryInfo = new CountryInfo();
  public countryOfBirth: CountryInfo = new CountryInfo();
  public residenceABD: string;
  public identityType: LookupInfo = new LookupInfo();
  public identitySerialNo: string;
  public hasDoubleCitzenship: string;
  public foreignTelNo: string;
}