export class AddressInfo {
  public countryCode: string;
  public provinceCode: string;
  public districtCode: string;
  public zipCode: string;
  public addressArea1: string;
  public addressArea2: string;
  public addressArea3: string;
  public displayAddress: string;
  public id: number;
  public addressType:number;
}