export class AddressInfoRequest {
    public idNo: number;
    public tckn: string;
    public companyCode: string;
}