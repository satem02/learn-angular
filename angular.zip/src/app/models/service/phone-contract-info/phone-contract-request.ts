export class PhoneContractRequest {
    public tckn:number;
    public isYkb:boolean;
    public isHsbc:boolean;
    public agencyCode:string;
}
