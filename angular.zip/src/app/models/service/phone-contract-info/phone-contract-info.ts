export class PhoneContractInfo {
  public customerNo: number;
  public communicationOrder: number;
  public communicationType: string;
  public countryCode: string;
  public communicationInfo: string;
  public notes: string;
  public displayText: string = "";
}


