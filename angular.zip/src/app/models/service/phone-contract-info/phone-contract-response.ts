import { PhoneContractInfo } from "./phone-contract-info";

export class PhoneContractResponse {
  homeWorkNumberList: PhoneContractInfo[];
  faxList: PhoneContractInfo[];
  mobileNumberList: PhoneContractInfo[];
  emailList: PhoneContractInfo[];
}
