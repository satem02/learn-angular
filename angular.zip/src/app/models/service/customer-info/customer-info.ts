export class CustomerInfo {
    public agentRegisterNo: number;
    public agencyCode: number;
    public displayAgencyCode: number;
    public agencyName: string;
    public companyCode: number;
    public companyName: string;
    public agencyNo: string;
    public agentName: string;
    public agentSurname: string;
    public isHSBCAgent: boolean;
    public isHeadquarterEmployee: boolean;
  }
