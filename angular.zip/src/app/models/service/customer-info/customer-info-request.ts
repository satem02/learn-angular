export class CustomerInfoRequest {
    public tckn: string;
  }
  