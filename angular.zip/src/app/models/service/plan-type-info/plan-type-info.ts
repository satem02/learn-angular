export class PlanTypeInfo {
  public planCode: number;
  public planName: string;
}
