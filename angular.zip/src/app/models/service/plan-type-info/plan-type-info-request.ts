export class PlanTypeInfoRequest {
    public companyCode: string;
}