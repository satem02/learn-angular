export class AgentInfoRequest {
  public agencyCode: number;
  public company: number;
}
