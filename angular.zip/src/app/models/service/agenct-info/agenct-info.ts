export class AgenctInfo {
    public tckn: string;
    public name: string;
    public surName: string;
  }