export class IncomeLevelInfo {
    incomeLevelCode: string;
    incomeLevelName: string;
}


