export class DistrictInfo {
    public townCode: number;
    public townName: string;
}