export class DistrictInfoRequest {
    public cityCode: string;
}
 