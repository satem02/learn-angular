export class ProductDTO {
    public code: number;
    public name: string;
    public order: number;
    public isActive: boolean;
  }
  