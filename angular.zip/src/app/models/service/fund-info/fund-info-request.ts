export class FundInfoRequest {
  public companyCode: number;
  public planCode: number;
  public fundPackageCode: number;
}
