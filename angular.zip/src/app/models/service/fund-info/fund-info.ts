export class FundInfo {
  public fundCode: string;
  public fundName: string;
  public fundRate: number;
}