export class AgencyInfoRequest {
    public tckn: string;
    public company: string;
  }
  