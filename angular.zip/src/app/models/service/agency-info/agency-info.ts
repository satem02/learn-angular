export class AgencyInfo {
    public agencyCode: number;
    public agencyName: string;
    public isHSBC:boolean;
    public isYKB:boolean;
  }