export class FundPackageInfoRequest {
    public planType: number;
    public companyCode: number;
}