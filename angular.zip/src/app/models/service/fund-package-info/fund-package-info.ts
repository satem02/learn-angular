export class FundPackageInfo {
  public editFlag: string;
  public fundPackageCode: number;
  public fundPackageName: string;
}