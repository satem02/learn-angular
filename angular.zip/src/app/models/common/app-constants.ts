export interface IAppConstants {
  YES: string;
  NO: string;
  REAL:string;
  LEGAL:string;
  US:string;
}

export const AppConstants: IAppConstants = {
  YES: "Yes",
  NO: "No",
  REAL:"Gerçek",
  LEGAL:"Tüzel",
  US:"US"
};
