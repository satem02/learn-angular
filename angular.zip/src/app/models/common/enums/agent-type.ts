export enum AgentType {
    None = 0,
    ALL = 1,
    AZHE = 2,
    EZYE = 3
}
