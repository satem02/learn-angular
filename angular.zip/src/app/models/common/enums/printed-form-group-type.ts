export enum PrintedFormGroupType {
  None = 0,
  Yes = 'Yes',
  No = 'No'
}

