export enum InsuredFormSearchType {
    None = 0,
    RimNo = 'rimNo',
    IdentiyNo = 'identiyNo',
    BirtyDay = 'birthday',
    FatherName = 'fatherName',
}