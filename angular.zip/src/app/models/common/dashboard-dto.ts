export class DashboardDTO {
    public CustomerTCKN: number;
  }
  