import { FieldConfig } from './field-config';
import { AgentType } from '../enums/agent-type';

export class FieldConfigs {
    agentType: AgentType;
    fieldConfigs: FieldConfig[] =  new Array<FieldConfig>();
}

