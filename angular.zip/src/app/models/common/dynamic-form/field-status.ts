export enum FieldStatus {
    None = 0,
    Yes = 1,
    No = 2
}



