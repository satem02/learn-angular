export enum PageNames {
    None = 0,
    ProposalInformation = 1,
    StepInsured = 2
}
