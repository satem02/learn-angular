import { FieldStatus } from "./field-status";
export class FieldInfo {
    name: string;
    disabled: FieldStatus = FieldStatus.None;
    hide: FieldStatus = FieldStatus.None;
    required: FieldStatus = FieldStatus.None;
}
