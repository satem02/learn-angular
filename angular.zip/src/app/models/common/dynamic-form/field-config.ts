import { FieldInfo } from './field-info';
import { PageNames } from './page-names';

export class FieldConfig {
    pageName: PageNames = PageNames.None;
    fields: FieldInfo[] = new Array<FieldInfo>();
}
