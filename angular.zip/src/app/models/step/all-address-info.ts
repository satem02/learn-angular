import { AddressInfo } from "../service";

export class AllAddressInfo {
  residenceAddressInfo: AddressDetail = new AddressDetail();
  contactAddressInfo: ContactAddressDetail = new ContactAddressDetail();
  residentAddressInfo: ResidentAddressDetail = new ResidentAddressDetail();
}

export class AddressDetail {
  selectedAddress: AddressInfo = new AddressInfo();
}

export class ContactAddressDetail extends AddressDetail {
  isEqualResidenceContact: boolean = false;
}

export class ResidentAddressDetail extends AddressDetail {
  hasResidentAddress: boolean = false;
  hasResidentCertificaReceived: boolean = false;
}
