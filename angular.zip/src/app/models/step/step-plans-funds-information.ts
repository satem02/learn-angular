import { FundPackageInfo, PlanTypeInfo, FundInfo } from "../service";

export class PlansFundsDTO {
  public planType: PlanTypeInfo = new PlanTypeInfo();
  public fundPackage: FundPackageInfo = new FundPackageInfo();
  public dataSource: FundInfo[];
}
