import { EducationOccupationalInfo } from "./education-occupational-info";
import { ContactInformationInfo } from "./contact-information-info";
import { AllAddressInfo } from './all-address-info';
import { KPSInfo } from '../service/kps-info/kps-info';
import { FatcaInfo } from '../service/fatca-info/fatca-info';

export class InsuredDetailDTO {
  public customerType: string;
  public isSameContributor: string = "Yes";
  public educationOccupationalInfo: EducationOccupationalInfo = new EducationOccupationalInfo();
  public kpsResponse: KPSInfo = new KPSInfo();
  public contractInformation: ContactInformationInfo = new ContactInformationInfo();
  public allAddressInfo : AllAddressInfo = new AllAddressInfo();
  public fatcaInfo: FatcaInfo = new FatcaInfo();
  public segment : string;
}
 