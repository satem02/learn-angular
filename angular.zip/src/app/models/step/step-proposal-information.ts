import { AgencyInfo, ContractInfo } from "../service";
import * as moment from "moment";

export class ProposalInformationDTO {
  public CompanyCode: number;
  public AgentCode: number;
  public AgencyNo: string;
  public AgentText: string;
  public Agency: AgencyInfo = new AgencyInfo();
  public ProductType: ContractInfo = new ContractInfo();
  public PrintedFormGroup: boolean;
  public ProposalNo: number;
  public TransferPensionCompany: number;
  public TransferCompanyPensionNo: string;
  public GroupNo: number;
  public SubGroupNo: number;
  public SignatureDate = moment();
}
