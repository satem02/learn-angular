import { JobTypeInfo } from "../service/job-type-info/job-type-info";
import { IncomeLevelInfo } from "../service/income-level-info/income-level-info";
import { EducationInfo } from "../service/education-info/education-info";

export class EducationOccupationalInfo {
  public desc: string;
  public job: JobTypeInfo = new JobTypeInfo();
  public incomeLevel: IncomeLevelInfo = new IncomeLevelInfo();
  public education: EducationInfo = new EducationInfo();
  public registerNo: number;
}
