import { LookupInfo, CreditCardNoInfo  } from "../service";

export class PaymentInfoDTO {
  public paymentStartDate: Date;
  public paymentDay: number;
  public paymentPeriod: LookupInfo = new LookupInfo();
  public contributionAmount: string;
  public paymentMethod: LookupInfo = new LookupInfo();
  public creditCardNo: CreditCardNoInfo = new CreditCardNoInfo();
  public creditCartTypeText:string;
  public cardNo: string;
  public cvv: number;
  public expiryDateMonth: string ;
  public expiryDateYear: string;
  public cardOwner: string;
}
