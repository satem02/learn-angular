export class BeneficiaryDTO {
    public isSetBeneficiary: string = "No";
    public customerType: string;
  }
  