import { PhoneContractInfo } from '../service';

export class ContactInformationInfo {
  public selectedHomeWorkPhone: PhoneContractInfo = new PhoneContractInfo();
  public selectedFax: PhoneContractInfo = new PhoneContractInfo();
  public selectedMobilePhone: PhoneContractInfo = new PhoneContractInfo();
  public selectedEPosta: PhoneContractInfo = new PhoneContractInfo();
}
