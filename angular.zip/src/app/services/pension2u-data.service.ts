import { Injectable } from "@angular/core";
import { Observable } from "rxjs/internal/Observable";
import { map, tap } from "rxjs/operators";
import { ApiService } from "./core/api-service";
import {
  AgencyInfoRequest,
  AgencyInfo,
  GenericResponseType,
  GroupInfo,
  SubGroupInfoRequest,
  AgentInfoRequest,
  AgenctInfo,
  CompanyInfoRequest,
  CompanyInfo,
  KPSInfo,
  KPSInfoRequest,
  LookupInfo,
  PlanTypeInfoRequest,
  PlanTypeInfo,
  FundPackageInfo,
  FundPackageInfoRequest,
  FundInfoRequest,
  FundInfo,
  PaymentPeriodInfo,
  PaymentTypeInfo,
  CreditCardNoInfo
} from "../models/service";
import { DistrictInfoRequest } from "../models/service/district-info/district-info-request";
import { DistrictInfo } from "../models/service/district-info/district-info";
import { OrderPipe } from "ngx-order-pipe";

@Injectable()
export class Pension2uDataService {
  private readonly baseURL = "rest/";
  private readonly agencyUriBase = this.baseURL + "AgencyTypeService";
  private readonly groupUriBase = this.baseURL + "GroupTypeService";
  private readonly subGroupUriBase = this.baseURL + "SubGroupTypeService";
  private readonly agentUriBase = this.baseURL + "AgentTypeService";
  private readonly pensionCompanyTypeUriBase =
    this.baseURL + "CompanyTypeService";
  private readonly kpsInfoUriBase = this.baseURL + "KpsService";
  private readonly districtUriBase = this.baseURL + "TownTypeService";
  private readonly lookupTypeUriBase = this.baseURL + "LookupTypeService";
  private readonly planTypeUriBase = this.baseURL + "PlanTypeService";
  private readonly fundPlanTypeUriBase =
    this.baseURL + "FundPackageTypeService";
  private readonly fundUriBase = this.baseURL + "FundTypeService";
  private readonly paymentPeriodUriBase = this.baseURL + "payment-period";
  private readonly paymentTypeUriBase = this.baseURL + "payment-type";
  private readonly creditCardUriBase = this.baseURL + "credit-card";

  constructor(private apiService: ApiService, private orderPipe: OrderPipe) {}

  getAgencyList(input: AgencyInfoRequest): Observable<AgencyInfo[]> {
    return this.apiService
      .post(`${this.agencyUriBase}/getAgencyTypeById`, input)
      .pipe(map((response: GenericResponseType<any>) => response.dataOutput));
  }

  getGroupList(): Observable<GroupInfo[]> {
    return this.apiService
      .post(`${this.groupUriBase}/getGroupTypeById`)
      .pipe(map((response: GenericResponseType<any>) => response.dataOutput));
  }

  getSubGroupList(input: SubGroupInfoRequest): Observable<GroupInfo[]> {
    return this.apiService
      .post(`${this.subGroupUriBase}/getSubGroupTypeById`, input)
      .pipe(map((response: GenericResponseType<any>) => response.dataOutput));
  }

  getAgentList(input: AgentInfoRequest): Observable<AgenctInfo[]> {
    return this.apiService
      .post(`${this.agentUriBase}/getAgentTypeById`, input)
      .pipe(map((response: GenericResponseType<any>) => response.dataOutput));
  }

  getPensionCompanyTypeList(
    input: CompanyInfoRequest
  ): Observable<CompanyInfo[]> {
    return this.apiService
      .post(`${this.pensionCompanyTypeUriBase}/getPensionCompanyType`, input)
      .pipe(map((response: GenericResponseType<any>) => response.dataOutput));
  }

  getKPSInfo(input: KPSInfoRequest): Observable<KPSInfo> {
    return this.apiService
      .post(`${this.kpsInfoUriBase}/queryKps`, input)
      .pipe(map((response: GenericResponseType<any>) => response.dataOutput));
  }

  getDistricts(input: DistrictInfoRequest): Observable<DistrictInfo> {
    return this.apiService
      .post(`${this.districtUriBase}/getTownTypeById`, input)
      .pipe(map((response: GenericResponseType<any>) => response.dataOutput));
  }

  getIdentityRegisterTypes(): Observable<LookupInfo[]> {
    return this.apiService
      .post(`${this.lookupTypeUriBase}/getIdentityRegisterTypes`)
      .pipe(map((response: GenericResponseType<any>) => response.dataOutput));
  }

  getPlanTypeByCompany(input: PlanTypeInfoRequest): Observable<PlanTypeInfo[]> {
    return this.apiService
      .post(`${this.planTypeUriBase}/getPlanTypeByCompany`, input)
      .pipe(
        map((response: GenericResponseType<any>) =>
          this.orderPipe.transform(response.dataOutput, "planCode")
        )
      );
  }

  getFundPackageTypeByPlan(
    input: FundPackageInfoRequest
  ): Observable<FundPackageInfo[]> {
    return this.apiService
      .post(`${this.fundPlanTypeUriBase}/getFundPackageTypeByPlan`, input)
      .pipe(map((response: GenericResponseType<any>) => response.dataOutput));
  }

  getFundTypeByFundPackageCode(input: FundInfoRequest): Observable<FundInfo[]> {
    return this.apiService
      .post(`${this.fundUriBase}/getFundTypeByFundPackageCode`, input)
      .pipe(map((response: GenericResponseType<any>) => response.dataOutput));
  }

  getPaymentPeriodList(): Observable<PaymentPeriodInfo[]> {
    return this.apiService
      .get(`${this.paymentPeriodUriBase}`)
      .pipe(map((response: any) => response));
  }

  getPaymentTypes(): Observable<PaymentTypeInfo[]> {
    return this.apiService
      .get(`${this.paymentTypeUriBase}`)
      .pipe(map((response: any) => response));
  }

  getCreditCards(rimno: number): Observable<CreditCardNoInfo[]> {
    return this.apiService
      .get(`${this.creditCardUriBase}/rim/` + rimno)
      .pipe(map((response: any) => response));
  }
}
