import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import * as moment from 'moment';

@Injectable({
  providedIn: 'root'
})
export class DatePickerService {

  private currentDate = moment();
  private english = {
    firstDayOfWeek: 0,
    dayNames: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
    dayNamesShort: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
    dayNamesMin: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
    monthNames: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
    monthNamesShort: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
    today: 'Today',
    clear: 'Clear'
  };
  private turkish = {
    firstDayOfWeek: 1,
    dayNames: ["Pazar", "Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi"],
    dayNamesShort: ["Paz", "Pzrt", "Sal", "Çar", "Per", "Cum", "Crts"],
    dayNamesMin: ["Paz", "Pzrt", "Sa", "Çar", "Per", "Cu", "Cmt"],
    monthNames: ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"],
    monthNamesShort: ["Oca", "Şub", "Mar", "Nis", "May", "Haz", "Tem", "Ağu", "Eyl", "Eki", "Kas", "Ara"],
    today: 'Bugün',
    clear: 'Temizle'
  };


  constructor(public translate: TranslateService) {
    this.currentDate = moment();
  }

  public getCalendarLocale(): any {
    if (this.translate) {
      if (this.translate.currentLang === 'tr') {
        return this.turkish;
      }
    }
    return this.english;
  }

  getCurrentDate() {
    return this.currentDate;
  }

  getPreviousMonth() {
    var previousMonth = moment();
    if (this.currentDate.month() == 1) {
      previousMonth.date(this.currentDate.year() - 1)
      previousMonth.month(11);
    }
    else {
      previousMonth.month(this.currentDate.month() - 1);
    }
    return previousMonth;
  }

  getNextMonth() {
    var nextMonth = moment();
    if (this.currentDate.month() == 11) {
      nextMonth.date(this.currentDate.year() + 1)
      nextMonth.month(0);
    }
    else {
      nextMonth.month(this.currentDate.month() + 1);

    }
    return nextMonth;
  }
}
