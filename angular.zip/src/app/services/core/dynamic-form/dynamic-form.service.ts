import { Injectable } from '@angular/core';
import { FieldConfig, FieldConfigs, FieldInfo, FieldStatus } from '../../../models/common/dynamic-form/index';
import { PageNames } from 'src/app/models/common/dynamic-form/page-names';
import { FormGroup, Validators } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class DynamicFormService {

  constructor() {

  }

  getFields() {
    let response = new FieldConfigs();
    response.agentType = 1;
    let fieldsConfigs = new FieldConfig();
    //let field = new FieldInfo();
    //field.name = "transferCompanyPensionNo";
    //field.disabled = 1;
    //field.required = 2;
    //field.hide = 1;
    fieldsConfigs.pageName = 1;
    //fieldsConfigs.fields.push(field);
    response.fieldConfigs.push(fieldsConfigs);

    return response;
  }


  setFiledsStatusWithPageName(activeForm: FormGroup, pageName: PageNames) {

    let allFields = this.getFields();
    let pageFields = allFields.fieldConfigs.find(x => x.pageName == pageName).fields;
    let noneRequiredNameList = [];

    for (let fieldInfo of pageFields) {
      let activeInput = activeForm.get(fieldInfo.name);
      if (activeInput) {

        if (fieldInfo.disabled == FieldStatus.Yes) {
          activeInput.disable();
        }
        else if (fieldInfo.disabled == FieldStatus.No) {
          activeInput.enable();
        }

        if (fieldInfo.hide == FieldStatus.Yes) {
          activeForm.removeControl(fieldInfo.name);
        }

        if (fieldInfo.required == FieldStatus.No) {
          noneRequiredNameList.push(fieldInfo.name);
        }
      }
    }

    Object.keys(activeForm.controls).forEach(key => {
      if (noneRequiredNameList.indexOf(key) < 0) {
        let selectedControl = activeForm.controls[key];
        if (selectedControl.validator)
          selectedControl.setValidators([selectedControl.validator, Validators.required]);
        else
          selectedControl.setValidators(Validators.required);
        selectedControl.updateValueAndValidity();
      }
    });
  }
}
