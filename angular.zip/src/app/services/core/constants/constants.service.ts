import { Injectable } from "@angular/core";
import { Observable } from "rxjs/internal/Observable";
import { DropdownDTO } from "src/app/models/service";
import { DatePickerService } from "../utilities/date-picker.service";

@Injectable()
export class ConstantsService {
  constructor(private dateService: DatePickerService) {}

  getContactTypeList(): Observable<DropdownDTO[]> {
    return new Observable<DropdownDTO[]>(observer => {
      let contactTypes: DropdownDTO[] = [
        {
          code: "TEL",
          displayText: "Ev/İş Telefonu",
          order: 1,
          isActive: true
        },
        { code: "FAX", displayText: "Fax", order: 2, isActive: true },
        {
          code: "CEP",
          displayText: "Cep Telefonu",
          order: 3,
          isActive: true
        },
        { code: "EML", displayText: "Mail", order: 4, isActive: true }
      ];
      observer.next(contactTypes);
    });
  }

  getPaymentDayList(): Observable<number[]> {
    return new Observable<number[]>(observer => {
      let dayList = [];
      for (let index = 1; index < 32; index++) {
        dayList.push(index);
      }
      observer.next(dayList);
    });
  }

  getMonthList(): Observable<string[]> {
    return new Observable<string[]>(observer => {
      let monthList = [];
      for (let index = 1; index < 10; index++) {
        monthList.push("0" + index);
      }
      
      monthList.push("11");
      monthList.push("12");
      observer.next(monthList);
    });
  }

  getYearList(): Observable<string[]> {
    return new Observable<string[]>(observer => {
      let yearList = [];
      let activeYear = this.dateService.getCurrentDate().year();
      let startYear = activeYear - 11;
      let endYear = activeYear + 11;
      for (let index = startYear; index < endYear; index++) {
        let result = (""+index).substring(2, 4);
        yearList.push(result);
      }
      observer.next(yearList);
    });
  }
}
