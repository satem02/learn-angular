import { Injectable, Inject } from '@angular/core';
import { LogLevel } from './log-level';
import { LogPublishersService } from './log-publishers-service';
import { LogPublisher } from './log-publisher';

@Injectable({
    providedIn: 'root'
})
export class LogEngineService {
    private _logLevel: LogLevel;
    private _publishers: LogPublisher[];
    private SEPARATOR = " ";
    
    constructor(@Inject('environment.logLevel') logLevel: LogLevel, logPublisherService: LogPublishersService) {
        this._logLevel = logLevel;
        this._publishers = logPublisherService.publishers;
    }

    log(message: any) {
        this.addLogPublisherLog(message);
    }


    debug(message: any) {
        if (this.checkAddLog(LogLevel.Debug)) {
            let logEntry = this.createLogStatement('debug', message);
            this.addLogPublisherDebug(logEntry);
        }
    }

    error(message: any) {
        if (this.checkAddLog(LogLevel.Error)) {
            let logEntry = this.createLogStatement('error', message);
            this.addLogPublisherError(logEntry);
        }
    }

    warn(message: any) {
        if (this.checkAddLog(LogLevel.Warn)) {
            let logEntry = this.createLogStatement('warning', message);
            this.addLogPublisherWarn(logEntry);
        }
    }

    info(message: any) {
        if (this.checkAddLog(LogLevel.Info)) {
            let logEntry = this.createLogStatement('info', message);
            this.addLogPublisherInfo(logEntry);
        }
    }

    private createLogStatement(level, message) {
        let date = this.getCurrentDate();
        return "[" + level + "]" + this.SEPARATOR + date + this.SEPARATOR + message;
    }

    private getCurrentDate() {
        let now = new Date();
        return "[" + now.toLocaleString() + "]";
    }

    private checkAddLog(logLevel: LogLevel) {
        if (this._logLevel == LogLevel.Off)
            return false;
        if (this._logLevel > logLevel)
            return false;
        return true;
    }
    private addLogPublisherLog(message: any) {
        for (let logger of this._publishers) {
            logger.log(message);
        }
    }

    private addLogPublisherDebug(message: any) {
        for (let logger of this._publishers) {
            logger.debug(message);
        }
    }
    private addLogPublisherError(message: any) {
        for (let logger of this._publishers) {
            logger.error(message);
        }
    }
    private addLogPublisherInfo(message: any) {
        for (let logger of this._publishers) {
            logger.info(message);
        }
    }
    private addLogPublisherWarn(message: any) {
        for (let logger of this._publishers) {
            logger.warn(message);
        }
    }
}