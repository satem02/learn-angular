import { Observable } from 'rxjs';

export interface LogPublisher {
  debug(message: any): Observable<void>;

  error(message: any): Observable<void>;

  warn(message: any): Observable<void>;

  info(message: any): Observable<void>;
  
  log(message: any): Observable<void>;
}