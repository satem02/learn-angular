import { LogPublisher } from '../log-publisher';
import { Observable } from 'rxjs';

export class LogConsole implements LogPublisher {
    log(message: any): Observable<void> {
        return Observable.create(console.log(message));
    }

    debug(message: any): Observable<void> {
        return Observable.create(console.debug(message));
    }

    error(message: any): Observable<void> {
        return Observable.create(console.error(message));
    }

    warn(message: any): Observable<void> {
        return Observable.create(console.warn(message));
    }

    info(message: any): Observable<void> {
        return Observable.create(console.info(message));
    }
}
