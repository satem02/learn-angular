import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { DashboardDTO } from 'src/app/models/common/dashboard-dto';

@Component({
  selector: 'app-dashboard-main',
  templateUrl: './dashboard-main.component.html',
  styleUrls: ['./dashboard-main.component.scss']
})
export class DashboardMainComponent implements OnInit {
  inputModel: DashboardDTO = new DashboardDTO();
  DashboardFormGroup: FormGroup;
  constructor(private formBuilder: FormBuilder) { }


  ngOnInit() {

    this.DashboardFormGroup = this.formBuilder.group({
      customerTCKN: new FormControl('', Validators.required)
    });
  }
}
