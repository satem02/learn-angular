import {
  Component,
  OnInit,
  Inject,
  AfterViewInit,
  EventEmitter,
  ViewChild,
  Input
} from "@angular/core";
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from "@angular/forms";
import { Pension2uFacade } from "src/app/+state/pension2u.facade";
import { PrintedFormGroupType } from "src/app/models/common/enums/printed-form-group-type";
import { ProposalInformationDTO } from "src/app/models/step/step-proposal-information";
import { DynamicFormService } from "src/app/services/core/dynamic-form/dynamic-form.service";
import { DatePickerService } from "src/app/services/core/utilities/date-picker.service";
import { Pension2uDataService } from "src/app/services/pension2u-data.service";
import { AgencyInfoRequest } from "src/app/models/service/agency-info/agency-info-request";
import { SubGroupInfoRequest } from "src/app/models/service/group-info/sub-group-info-request";
import { AgentInfoRequest } from "src/app/models/service/agenct-info/agenct-info-request";
import { CompanyInfoRequest } from "src/app/models/service/company-info/company-info-request";
import { of } from "rxjs";
import { PageNames } from "src/app/models/common/dynamic-form/page-names";
import { MatStepper } from "@angular/material/stepper";
import * as moment from "moment";
import { ContractInfo } from 'src/app/models/service';

@Component({
  selector: "app-step-proposal-information",
  templateUrl: "./step-proposal-information.component.html",
  styleUrls: ["./step-proposal-information.component.scss"],
  providers: []
})
export class StepProposalInformationComponent implements OnInit {
  @Input() myStepper: MatStepper;

  minDate = moment();
  maxDate = moment();

  ProposalInformationFormGroup: FormGroup;
  proposalInformationDTO: ProposalInformationDTO;

  companyList$ = this.service.companyList$;
  customerInfo$ = this.service.customerInfo$;
  contractList$ = this.service.contractList$;
  groupList$;
  subGroupList$;
  agentList$;
  pensionCompanyList$;

  private _isAZHEAgency: boolean = false;
  private _canChangePrintedFormGroupValue: boolean = true;
  _showProposalNo: boolean = false;
  _showGroup: boolean = false;
  _showTransferContract: boolean = false;
  private _printedFormGroupValue: PrintedFormGroupType =
    PrintedFormGroupType.No;
  _isGeneralManagerUser: boolean = false;

  constructor(
    private formBuilder: FormBuilder,
    private service: Pension2uFacade,
    private validationManager: DynamicFormService,
    private datePickerService: DatePickerService,
    private dataService: Pension2uDataService
  ) {}

  ngOnInit() {
    this.customerInfo$.subscribe(res => {
      this.formInitValue();
      this.formInitValidations();
      this.createForm();
      this.validationManager.setFiledsStatusWithPageName(
        this.ProposalInformationFormGroup,
        PageNames.ProposalInformation
      );
    });
  }

  formInitValue() {
    this.proposalInformationDTO = new ProposalInformationDTO();

    this.proposalInformationDTO.SignatureDate = this.datePickerService.getCurrentDate();
    this.customerInfo$.subscribe(res => {
      if (
        res != undefined &&
        res != null &&
        res.isHeadquarterEmployee != undefined &&
        res.isHeadquarterEmployee != null
      ) {
        this._isGeneralManagerUser = res.isHeadquarterEmployee;
        this.proposalInformationDTO.AgencyNo = res.agencyNo;
        if (!this._isGeneralManagerUser) {
          this._isAZHEAgency = res.companyCode == 52 && !res.isHSBCAgent;
          this.proposalInformationDTO.CompanyCode = res.companyCode;
          this.proposalInformationDTO.AgentCode = res.agentRegisterNo;
          this.proposalInformationDTO.AgentText =
            res.agencyNo + " - " + `${res.agentName} ${res.agentSurname}`;
          this.proposalInformationDTO.Agency.agencyCode = res.displayAgencyCode;
          this.proposalInformationDTO.Agency.agencyName = res.agencyName;
          this.loadContractList(res.companyCode);
          this.loadAgentList();
          this.getAgencyForm().disable();
          this.loadPensionCompany();
        }
      }
    });

    this.proposalInformationDTO.SignatureDate = this.datePickerService.getCurrentDate();
    this.minDate = this.datePickerService.getPreviousMonth();
    this.maxDate = this.datePickerService.getCurrentDate();
  }

  formInitValidations() {
    if (this._isAZHEAgency) {
      this._showProposalNo = true;
      this._canChangePrintedFormGroupValue = false;
      this._printedFormGroupValue = PrintedFormGroupType.Yes;
    }

    if (this._printedFormGroupValue == PrintedFormGroupType.No) {
      this.proposalInformationDTO.SignatureDate = this.datePickerService.getCurrentDate();
    }
  }

  createForm() {
    this.ProposalInformationFormGroup = this.formBuilder.group({
      companyCode: new FormControl(this.proposalInformationDTO.CompanyCode),

      agencyCode: new FormControl(
        this.proposalInformationDTO.Agency.agencyCode
      ),

      productType: new FormControl({
        value: this.proposalInformationDTO.ProductType.description,
        disabled: false
      }),

      printedFormGroup: new FormControl({
        value: this._printedFormGroupValue,
        disabled: !this._canChangePrintedFormGroupValue
      }),

      proposalNo: new FormControl(
        {
          value: this.proposalInformationDTO.ProposalNo,
          disabled: !this._showProposalNo
        },
        [Validators.min(10000000), Validators.max(99999999)]
      ),

      transferPensionCompany: new FormControl(
        this.proposalInformationDTO.TransferPensionCompany
      ),

      transferCompanyPensionNo: new FormControl(
        this.proposalInformationDTO.TransferCompanyPensionNo,
        [Validators.min(10000000), Validators.max(99999999)]
      ),

      groupNo: new FormControl({
        value: this.proposalInformationDTO.GroupNo,
        disabled: false
      }),

      subGroupNo: new FormControl({
        value: this.proposalInformationDTO.SubGroupNo,
        disabled: false
      }),

      agencyNo: new FormControl(this.proposalInformationDTO.AgencyNo),

      signatureDate: new FormControl(this.proposalInformationDTO.SignatureDate)
    });
  }

  loadContractList(companyCode: number) {
    this.service.contractList$.subscribe(res => {
      var result = res.filter(x => x.company == companyCode);

      if (result) {
        this.contractList$ = of(result);
      }
    });
  }

  loadAgentList() {
    var request = new AgentInfoRequest();
    request.agencyCode = this.proposalInformationDTO.Agency.agencyCode;
    request.company = this.proposalInformationDTO.CompanyCode;
    this.agentList$ = this.dataService.getAgentList(request);
  }

  contractTypeChange(event: ContractInfo) {
    this._showGroup = false;
    this.getGroupForm().disable();
    this.getSubGroupForm().disable();

    this._showTransferContract = false;
    this.getTransferPensionCompanyForm().disable();
    this.getTransferCompanyPensionNoForm().disable();

    if (event.value == "GDP") {
      this._showGroup = true;
      this._showTransferContract = false;
      this.getGroupForm().enable();
      this.getSubGroupForm().enable();
      this.groupList$ = this.dataService.getGroupList();
    } else if (event.value == "CBT") {
      this._showGroup = false;
      this._showTransferContract = true;
      this.getTransferPensionCompanyForm().enable();
      this.getTransferCompanyPensionNoForm().enable();
    }
  }

  printedFormChange(event: any) {
    this._printedFormGroupValue = event.value;
    if (this._printedFormGroupValue == PrintedFormGroupType.Yes) {
      this._showProposalNo = true;
      this.getProposalNoForm().enable();
      this.proposalInformationDTO.SignatureDate = null;
    } else {
      this._showProposalNo = false;
      this.getProposalNoForm().disable();
      this.proposalInformationDTO.SignatureDate = this.datePickerService.getCurrentDate();
    }
  }

  groupNoChange(event: any) {
    var request = new SubGroupInfoRequest();
    request.groupCode = event;
    this.subGroupList$ = this.dataService.getSubGroupList(request);
  }

  agentCodeChange() {}

  companyCodeChange(event: any) {
    this.clearData();
    this.loadContractList(event);
    this.loadPensionCompany();
  }

  clearData() {
    this.contractTypeChange(new ContractInfo());
  }

  agencyCodeChange() {
    this.proposalInformationDTO.Agency.agencyName = null;
    if (
      this.proposalInformationDTO.CompanyCode != undefined &&
      this.proposalInformationDTO.CompanyCode != undefined
    ) {
      this.loadAgentList();
      this.setAgencyText();
    }
  }

  loadPensionCompany() {
    var request = new CompanyInfoRequest();
    request.companyCode = this.proposalInformationDTO.CompanyCode;
    this.pensionCompanyList$ = this.dataService.getPensionCompanyTypeList(
      request
    );
  }

  nextButtonClicked() {
    this.service.setProposalInformation(this.proposalInformationDTO);
    this.myStepper.next();
  }

  setAgencyText() {
    var input = new AgencyInfoRequest();
    input.tckn = this.proposalInformationDTO.AgencyNo.toString();
    input.company = this.proposalInformationDTO.CompanyCode.toString();
    let serviceResult$ = this.dataService.getAgencyList(input);

    serviceResult$.subscribe(res => {
      var row = res.find(
        p => p.agencyCode == this.proposalInformationDTO.Agency.agencyCode
      );
      if (row) {
        this.proposalInformationDTO.Agency = row;
      }
    });
  }

  getProposalNoForm() {
    return this.ProposalInformationFormGroup.get("proposalNo");
  }

  getAgencyForm() {
    return this.ProposalInformationFormGroup.get("agencyCode");
  }

  getAgencyNoForm() {
    return this.ProposalInformationFormGroup.get("agencyNo");
  }

  getTransferPensionCompanyForm() {
    return this.ProposalInformationFormGroup.get("transferPensionCompany");
  }

  getTransferCompanyPensionNoForm() {
    return this.ProposalInformationFormGroup.get("transferCompanyPensionNo");
  }

  getGroupForm() {
    return this.ProposalInformationFormGroup.get("groupNo");
  }

  getSubGroupForm() {
    return this.ProposalInformationFormGroup.get("subGroupNo");
  }
}