import {
  Component,
  OnInit,
  Input,
  Inject,
  ChangeDetectorRef
} from "@angular/core";
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from "@angular/forms";
import { Pension2uFacade } from "src/app/+state/pension2u.facade";
import { ConfirmationDialogService } from "../../common/confirmation-dialog/confirmation-dialog.service";
import {
  ModalButtonCombinations,
  ModalButton
} from "../../common/confirmation-dialog/confirmation-dialog.enums";
import { take } from "rxjs/operators";
import { TranslateService } from "@ngx-translate/core";
import { InsuredFormSearchType } from "src/app/models/common/enums/insured-form-search-type";
import { KPSInfoRequest } from "src/app/models/service/kps-info/kps-info-request";
import { KPSInfo } from "src/app/models/service/kps-info/kps-info";
import { Pension2uDataService } from "src/app/services/pension2u-data.service";
import { MatStepper } from "@angular/material/stepper";
import { AddressInfoRequest } from "src/app/models/service/address-info/address-info-request";
import {
  PhoneContractRequest,
  LookupInfoRequest
} from "src/app/models/service";
import { InsuredDetailDTO } from "src/app/models/step";
import {
  AppConstants,
  IAppConstants
} from "src/app/models/common/app-constants";

@Component({
  selector: "app-step-insured",
  templateUrl: "./step-insured.component.html",
  styleUrls: ["./step-insured.component.scss"]
})
export class StepInsuredComponent implements OnInit {
  @Input() myStepper: MatStepper;
  _showErrorMessage: boolean = false;
  ServiceResponseMessage: string;
  InsuredFormGroup: FormGroup;
  InsuredDetailFormGroup: FormGroup;
  kpsRequest: KPSInfoRequest = new KPSInfoRequest();
  InsuredDetailDTO: InsuredDetailDTO = new InsuredDetailDTO();
  kpsResponse: KPSInfo = new KPSInfo();
  showDetailForm: boolean = false;
  customerInfo$ = this.service.customerInfo$;
  proposalInformation$ = this.service.proposalInformation$;
  companyList$ = this.service.companyList$;
  segmentList$;
  returnKPSResult: boolean = false;

  constructor(
    private cdRef: ChangeDetectorRef,
    @Inject(AppConstants) private constants: IAppConstants,
    private formBuilder: FormBuilder,
    private service: Pension2uFacade,
    private confirmationDialogService: ConfirmationDialogService,
    private pension2uDataService: Pension2uDataService,
    private translateService: TranslateService
  ) {}

  ngAfterViewInit() {
    this.cdRef.detectChanges();
  }
  createForm() {
    this.InsuredFormGroup = this.formBuilder.group({
      rimNo: ["", this.setRequired(InsuredFormSearchType.RimNo)],
      identiyNo: ["", this.setRequired(InsuredFormSearchType.IdentiyNo)],
      birthday: ["", this.setRequired(InsuredFormSearchType.BirtyDay)],
      fatherName: ["", this.setRequired(InsuredFormSearchType.FatherName)]
    });

    this.InsuredDetailFormGroup = this.formBuilder.group({
      identityNo: [{ value: this.kpsResponse.identityNo, disabled: true }],
      gender: new FormControl({
        value: this.kpsResponse.gender,
        disabled: true
      }),

      name: [{ value: this.kpsResponse.name, disabled: true }],
      surname: [{ value: this.kpsResponse.surname, disabled: true }],
      placeOfBirth: [{ value: this.kpsResponse.placeOfBirth, disabled: true }],
      dateOfBirth: [{ value: this.kpsResponse.dateOfBirth, disabled: true }],
      motherName: [{ value: this.kpsResponse.motherName, disabled: true }],
      fatherName: [{ value: this.kpsResponse.fatherName, disabled: true }],
      nationatily: [{ value: this.kpsResponse.nationatily, disabled: true }],
      maritalStatus: [
        { value: this.kpsResponse.maritalStatus, disabled: true }
      ],
      sectorCode: [],
      ykbcustomerNo: [
        { value: this.kpsResponse.ykbcustomerNo, disabled: true }
      ],
      segment: [],
      blueCardIssueDate: [],
      isSameContributor: [this.constants.YES],
      customerType: []
    });
  }

  setRequired(type: InsuredFormSearchType) {
    // if (type == InsuredFormSearchType.FatherName)
    // return Validators.required;
  }

  ngOnInit() {
    this.createForm();
    this.customerInfo$.subscribe(res => {
      if (res != null && res.isHeadquarterEmployee != null)
        this.kpsRequest.isHeadquarterEmployee = res.isHeadquarterEmployee;
    });

    this.callComboServices();
  }

  btnSearchClick() {
    this.showDetailForm = false;
    this.queryKPS();
  }

  callComboServices() {
    this.getCountryCodeList();
    this.service.loadCountryList();
    this.service.loadProvinceList();
    //this.queryContactType(26276);
  }

  getCountryCodeList() {
    var request = new LookupInfoRequest();
    this.service.loadCountryPhoneCodes(request);
  }

  queryKPS() {
    this.returnKPSResult = true;
    this._showErrorMessage = false;
    this.pension2uDataService.getKPSInfo(this.kpsRequest).subscribe(res => {
      this.returnKPSResult = false;
      if (res.rpaAnswer == "N") {
        this._showErrorMessage = true;
        this.ServiceResponseMessage = res.rpaWarning;
      } else if (res.identityNo) {
        var resModel = res;
        resModel.gender =
          resModel.gender != null ? resModel.gender.substring(0, 1) : "";
        this.kpsResponse = resModel;
        this.showDetailForm = true;
        this.callServices(res.identityNo);
      } else {
        this.showDialog();
      }
    });
  }

  setCreditCard() {
    this.pension2uDataService
      .getCreditCards(this.kpsRequest.rimNo)
      .subscribe(res => {
        if (res) {
          this.kpsResponse.creditCards = res;
        }
      });
  }

  callServices(identityNo: number) {
    this.queryKPSAddress(identityNo);
    this.queryResidenceAddress(identityNo);
    this.queryResidenteAddress(identityNo);
    this.queryContactType(identityNo);
    this.kpsRequest.rimNo = 3559312;
    this.setCreditCard();
  }

  queryKPSAddress(tckn: number) {
    var request = new AddressInfoRequest();
    request.idNo = tckn;
    this.service.loadResidenceAddressInfoList(request);
  }

  queryContactType(tckn: number) {
    var request = new PhoneContractRequest();
    this.proposalInformation$.subscribe(res => {
      request.isHsbc = res.Agency.isHSBC;
      request.isYkb = res.Agency.isYKB;
      request.tckn = tckn;
      request.agencyCode = res.Agency.agencyCode.toString();
    });
    this.service.loadContactType(request);
  }

  queryResidenceAddress(tckn: number) {
    var request = new AddressInfoRequest();
    request.tckn = tckn.toString();
    this.proposalInformation$.subscribe(res => {
      request.companyCode = res.Agency.agencyCode.toString();
    });

    this.service.loadAddressContractInfoList(request);
  }

  queryResidenteAddress(tckn: number) {
    var request = new AddressInfoRequest();
    request.tckn = tckn.toString();
    this.proposalInformation$.subscribe(res => {
      request.companyCode = res.Agency.agencyCode.toString();
    });

    this.service.loadResidenteAddressInfoList(request);
  }

  showDialog() {
    this.confirmationDialogService
      .show(
        this.translateService.instant("STEP_INSURED_TEXTS.SEARCH_ERROR"),
        this.translateService.instant("STEP_INSURED_TEXTS.NOT_FOUND"),
        ModalButtonCombinations.Ok,
        ModalButton.Ok
      )
      .pipe(take(1))
      .subscribe((button: ModalButton) => {
        if (ModalButton.Ok === button) {
        }
      });
  }
  isSameContributorChange() {
    this.InsuredDetailDTO.customerType = null;
  }

  setData() {
    this.InsuredDetailDTO = this.InsuredDetailFormGroup.value;
    this.InsuredDetailDTO.kpsResponse = this.kpsResponse;
    this.service.setInsuredDetail(this.InsuredDetailDTO);
  }

  nextButtonClicked() {
    this.setData();

    if (this.InsuredDetailDTO.isSameContributor === this.constants.YES) {
      this.service.setInsurerDetail(this.InsuredDetailDTO);
      this.checkWhichStep();
    } else {
      this.myStepper.linear = false;
      this.myStepper.selectedIndex = 2;
      this.myStepper.linear = true;
    }
  }

  checkWhichStep() {
    this.myStepper.steps.forEach(function(item, index) {
      if (index === 2) {
        item.completed = true;
      }
    });

    this.myStepper.linear = false;
    this.myStepper.selectedIndex = 3;
    this.myStepper.linear = true;
  }

  previousButtonClicked() {
    this.myStepper.previous();
  }
}
