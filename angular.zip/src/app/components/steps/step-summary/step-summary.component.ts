import { Component, OnInit, Input } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { MatStepper } from "@angular/material/stepper";
import { Pension2uFacade } from "src/app/+state";
import { ConfirmationDialogService } from "../../common/confirmation-dialog/confirmation-dialog.service";
import { TranslateService } from "@ngx-translate/core";
import {
  ModalButtonCombinations,
  ModalButton
} from "../../common/confirmation-dialog/confirmation-dialog.enums";
import { take } from "rxjs/operators";

@Component({
  selector: "app-step-summary",
  templateUrl: "./step-summary.component.html",
  styleUrls: ["./step-summary.component.scss"]
})
export class StepSummaryComponent implements OnInit {
  @Input() myStepper: MatStepper;
  SummaryFormGroup: FormGroup;
  proposalInformation$ = this.service.proposalInformation$;
  insuredDetail$ = this.service.insuredDetail$;
  insurerDetail$ = this.service.insurerDetail$;
  plansFunds$ = this.service.plansFunds$;
  paymentDetail$ = this.service.paymentDetail$;

  constructor(
    private formBuilder: FormBuilder,
    private confirmationDialogService: ConfirmationDialogService,
    private translateService: TranslateService,
    private service: Pension2uFacade
  ) {}

  ngOnInit() {
    this.SummaryFormGroup = this.formBuilder.group({});
  }

  underwriteButtonClicked() {}

  commercialElectronicMessageClicked() {
    let headerKey = "STEP_PROPOSAL_SUMMARY_TEXTS.COMMERCIAL_ELECTRONIC_HEADER";
    let messageKey = "STEP_PROPOSAL_SUMMARY_TEXTS.COMMERCIAL_ELECTRONIC_MESSAGE";

    this.showDialog(headerKey, messageKey);
  }

  permissionPersonelClicked() {
    let headerKey = "STEP_PROPOSAL_SUMMARY_TEXTS.PERMISSION_PERSONEL_HEADER";
    let messageKey = "STEP_PROPOSAL_SUMMARY_TEXTS.PERMISSION_PERSONEL_MESSAGE";

    this.showDialog(headerKey, messageKey);
  }

  showDialog(headerKey: string, messageKey: string) {
    this.confirmationDialogService
      .show(
        this.translateService.instant(messageKey),
        this.translateService.instant(headerKey),
        ModalButtonCombinations.Ok,
        ModalButton.Ok
      )
      .pipe(take(1))
      .subscribe((button: ModalButton) => {
        if (ModalButton.Ok === button) {
        }
      });
  }

  editButtonClicked(index: number) {
    this.myStepper.linear = false;
    this.myStepper.selectedIndex = index;
    this.myStepper.linear = true;
  }

  nextButtonClicked() {
    // TODO
    // this.myStepper.linear = false;
    // this.myStepper.selectedIndex = 6;
    // this.myStepper.linear = true;
  }

  previousButtonClicked() {
    // TODO
    this.myStepper.linear = false;
    this.myStepper.selectedIndex = 5;
    this.myStepper.linear = true;
  }
}
