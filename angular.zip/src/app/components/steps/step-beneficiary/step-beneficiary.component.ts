import { Component, OnInit, Input, Inject } from "@angular/core";
import { FormGroup, FormBuilder } from "@angular/forms";
import { MatStepper } from "@angular/material/stepper";
import { BeneficiaryDTO } from "src/app/models/step";

import {
  IAppConstants,
  AppConstants
} from "src/app/models/common/app-constants";
import { Pension2uFacade } from 'src/app/+state';

@Component({
  selector: "app-step-beneficiary",
  templateUrl: "./step-beneficiary.component.html",
  styleUrls: ["./step-beneficiary.component.scss"]
})
export class StepBeneficiaryComponent implements OnInit {
  @Input() myStepper: MatStepper;

  BeneficiaryFormGroup: FormGroup;
  beneficiary: BeneficiaryDTO = new BeneficiaryDTO();
  insuredDetail$ = this.service.insuredDetail$;

  constructor(
    @Inject(AppConstants) private constants: IAppConstants,
    private service: Pension2uFacade,
    private formBuilder: FormBuilder
  ) {}

  ngOnInit() {
    this.createForm();
  }

  createForm() {
    this.BeneficiaryFormGroup = this.formBuilder.group({
      isSetBeneficiary: []
    });
  }

  nextButtonClicked() {
    // TODO     
    this.myStepper.linear = false;
    this.myStepper.selectedIndex = 4;
    this.myStepper.linear = true;
  }

  previousButtonClicked() {
    // TODO
    let backStepIndex = 1;
    
    this.insuredDetail$.subscribe(res=>{
      if(res.isSameContributor == "No"){
        backStepIndex = 2;
      }
    })
    this.myStepper.linear = false;
    this.myStepper.selectedIndex = backStepIndex;
    this.myStepper.linear = true;
  }
}
