import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StepBeneficiaryComponent } from './step-beneficiary.component';

describe('StepBeneficiaryComponent', () => {
  let component: StepBeneficiaryComponent;
  let fixture: ComponentFixture<StepBeneficiaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StepBeneficiaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StepBeneficiaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
