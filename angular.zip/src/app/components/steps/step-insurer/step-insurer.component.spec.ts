import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StepInsurerComponent } from './step-insurer.component';

describe('StepInsurerComponent', () => {
  let component: StepInsurerComponent;
  let fixture: ComponentFixture<StepInsurerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StepInsurerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StepInsurerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
