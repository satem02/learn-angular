import { Component, OnInit, Input } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { MatStepper } from "@angular/material/stepper";

@Component({
  selector: "app-step-insurer",
  templateUrl: "./step-insurer.component.html",
  styleUrls: ["./step-insurer.component.scss"]
})
export class StepInsurerComponent implements OnInit {
  @Input() myStepper: MatStepper;

  InsurerFormGroup: FormGroup;

  constructor(private formBuilder: FormBuilder) {}

  ngOnInit() {
    this.InsurerFormGroup = this.formBuilder.group({});
  }

  nextButtonClicked() {
    // TODO     
    this.myStepper.linear = false;
    this.myStepper.selectedIndex = 3;
    this.myStepper.linear = true;
  }

  previousButtonClicked() {
    // TODO
    this.myStepper.linear = false;
    this.myStepper.selectedIndex = 1;
    this.myStepper.linear = true;
  }
}
