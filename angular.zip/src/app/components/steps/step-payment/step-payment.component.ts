import { Component, OnInit, Input } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { MatStepper } from "@angular/material/stepper";
import { PaymentInfoDTO } from "src/app/models/step";
import { DatePickerService } from "src/app/services/core/utilities/date-picker.service";
import { Pension2uFacade } from "src/app/+state";
import { ConstantsService } from "src/app/services/core/constants/constants.service";
import * as moment from "moment";
import { Pension2uDataService } from "src/app/services/pension2u-data.service";
import { CreditCardNoInfo } from "src/app/models/service";

@Component({
  selector: "app-step-payment",
  templateUrl: "./step-payment.component.html",
  styleUrls: ["./step-payment.component.scss"]
})
export class StepPaymentComponent implements OnInit {
  @Input() myStepper: MatStepper;
  model: PaymentInfoDTO = new PaymentInfoDTO();
  showDetailForm: boolean = false;
  showKK: boolean = false;
  paymentPeriodList$ = this.dataService.getPaymentPeriodList();
  paymentTypeList$ = this.dataService.getPaymentTypes();
  insuredDetail$ = this.service.insuredDetail$;
  monthList$ = this.constantService.getMonthList();
  yearList$ = this.constantService.getYearList();
  paymentDayList$ = this.constantService.getPaymentDayList();
  creditCards$: CreditCardNoInfo[] = [
    {
      creditCardNo: "",
      hiddenCreditCardNo: "Seçiniz",
      productCode: "",
      validityEndDate: ""
    }
  ];
  fullName: string;

  proposalInformation$ = this.service.proposalInformation$;
  minDate = moment();
  maxDate = moment();
  PaymentFormGroup: FormGroup;
  isHSBC: boolean = false;
  isDisabled = false;

  constructor(
    private formBuilder: FormBuilder,
    private service: Pension2uFacade,
    private dataService: Pension2uDataService,
    private constantService: ConstantsService,
    private datePickerService: DatePickerService
  ) {}

  ngOnInit() {
    this.maxDate = this.datePickerService.getNextMonth();
    this.minDate = this.datePickerService.getCurrentDate();
    this.createForm();
    this.setHSBSFlag();
  }

  creditCardNoChange(creditCardNo: CreditCardNoInfo) {
    if (creditCardNo.hiddenCreditCardNo != "Seçiniz") {
      this.isDisabled = true;
      this.model.cardOwner = this.fullName;
      this.model.cardNo = creditCardNo.hiddenCreditCardNo;
      this.model.expiryDateMonth= creditCardNo.validityEndDate.substring(0, 2);
      this.model.expiryDateYear= creditCardNo.validityEndDate.substring(2, 4);
      this.getCardNoForm().disable();
      this.getCardOwnerForm().disable();
    } else {
      this.model.cardOwner = "";
      this.model.cardNo = "";
      this.model.expiryDateMonth = "";
      this.model.expiryDateYear = "";
      this.isDisabled = false;
      this.getCardNoForm().enable();
      this.getCardOwnerForm().enable();
    }
  }

  setHSBSFlag() {
    this.proposalInformation$.subscribe(res => {
      if (res) {
        this.isHSBC = res.Agency.isHSBC;
        this.isHSBC = true;
        if (this.isHSBC) {
          this.fillHSBCData();
        }
      }
    });
  }

  fillHSBCData() {
    this.insuredDetail$.subscribe(res => {
      if (res) {
        let kps = res.kpsResponse;
        if (kps.creditCards) {
          this.creditCards$ = kps.creditCards;
          if (
            this.creditCards$.findIndex(
              x => x.hiddenCreditCardNo == "Seçiniz"
            ) == -1
          ) {
            this.creditCards$.push({
              creditCardNo: "",
              hiddenCreditCardNo: "Seçiniz",
              productCode: "",
              validityEndDate: ""
            });
          }
        }
        this.fullName = kps.name + " " + kps.surname;
      }
    });
  }

  createForm() {
    this.PaymentFormGroup = this.formBuilder.group({
      paymentStartDate: [],
      paymentDay: [],
      paymentPeriod: [],
      contributionAmount: [],
      paymentMethod: [],
      creditCardNo: [],
      cardNo: [],
      cvv: [],
      expiryDateMonth: [],
      expiryDateYear: [],
      cardOwner: []
    });
  }
  cardNoChange($event: any) {
    this.model.creditCartTypeText = "";
    let firstCharacterCardNo = ("" + $event)!.substring(0, 1);
    if (firstCharacterCardNo == "4") this.model.creditCartTypeText = "VISA";
    else if (firstCharacterCardNo == "5")
      this.model.creditCartTypeText = "MASTER";
    else if (firstCharacterCardNo == "9")
      this.model.creditCartTypeText = "TROY";
  }
  openCreditCartPanel() {
    this.showDetailForm = true;
  }

  nextButtonClicked() {
    this.service.setPaymentDetail(this.model);

    // TODO
    this.myStepper.linear = false;
    this.myStepper.selectedIndex = 6;
    this.myStepper.linear = true;
  }

  previousButtonClicked() {
    // TODO
    this.myStepper.linear = false;
    this.myStepper.selectedIndex = 4;
    this.myStepper.linear = true;
  }

  getCardNoForm() {
    return this.PaymentFormGroup.get("cardNo");
  }

  getCardOwnerForm() {
    return this.PaymentFormGroup.get("cardOwner");
  }
}
