import { Component, OnInit, Input, ChangeDetectorRef } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { MatStepper } from "@angular/material/stepper";
import { PlansFundsDTO } from "src/app/models/step";
import { Pension2uFacade } from "src/app/+state";
import { Pension2uDataService } from "src/app/services/pension2u-data.service";
import {
  PlanTypeInfoRequest,
  FundPackageInfoRequest,
  FundPackageInfo,
  FundInfoRequest,
  PlanTypeInfo
} from "src/app/models/service";

@Component({
  selector: "app-step-plans-funds",
  templateUrl: "./step-plans-funds.component.html",
  styleUrls: ["./step-plans-funds.component.scss"]
})
export class StepPlansFundsComponent implements OnInit {
  @Input() myStepper: MatStepper;
  fundList$;
  planList$;
  fundPackages$;

  PlansFundsFormGroup: FormGroup;
  plansFunds: PlansFundsDTO = new PlansFundsDTO();

  constructor(
    private cdRef: ChangeDetectorRef,
    private formBuilder: FormBuilder,
    private dataService: Pension2uDataService,
    private service: Pension2uFacade
  ) {}

  ngOnInit() {
    this.getPlanTypeByCompany();
    this.createForm();
  }
  ngAfterViewInit() {
    this.cdRef.detectChanges();
  }

  getPlanTypeByCompany() {
    let request = new PlanTypeInfoRequest();
    this.service.proposalInformation$.subscribe(res => {
      if (res.CompanyCode) {
        request.companyCode = res.CompanyCode.toString();
        this.planList$ = this.dataService.getPlanTypeByCompany(request);
      }
    });
  }

  createForm() {
    this.PlansFundsFormGroup = this.formBuilder.group({
      planType: [],
      fundPackage: []
    });
  }

  planChange(event: PlanTypeInfo) {
    this.getFundByCompany(event.planCode);
  }

  getFundByCompany(planCode: number) {
    let request = new FundPackageInfoRequest();
    this.service.proposalInformation$.subscribe(res => {
      if (res.CompanyCode) {
        request.companyCode = res.CompanyCode;
        request.planType = planCode;
        this.fundPackages$ = this.dataService.getFundPackageTypeByPlan(request);
      }
    });
  }

  fundPackageChange(fundPackage: FundPackageInfo) {
    this.getFundTypeByFundPackageCode(fundPackage);
  }

  getFundTypeByFundPackageCode(fundPackage: FundPackageInfo) {
    let request = new FundInfoRequest();
    this.service.proposalInformation$.subscribe(res => {
      if (res.CompanyCode) {
        request.companyCode = res.CompanyCode;
        request.fundPackageCode = fundPackage.fundPackageCode;
        request.planCode = this.plansFunds.planType.planCode;
        this.fundList$ = this.dataService.getFundTypeByFundPackageCode(request);
        this.fundList$.subscribe(res => {
          if (res) this.plansFunds.dataSource = res;
        });
      }
    });
  }

  nextButtonClicked() {
    this.service.setPlansFunds(this.plansFunds);
    this.myStepper.linear = false;
    this.myStepper.selectedIndex = 5;
    this.myStepper.linear = true;
  }

  previousButtonClicked() {
    this.myStepper.linear = false;
    this.myStepper.selectedIndex = 3;
    this.myStepper.linear = true;
  }
}
