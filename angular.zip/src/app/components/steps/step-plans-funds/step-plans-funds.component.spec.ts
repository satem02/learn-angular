import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StepPlansFundsComponent } from './step-plans-funds.component';

describe('StepPlansFundsComponent', () => {
  let component: StepPlansFundsComponent;
  let fixture: ComponentFixture<StepPlansFundsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StepPlansFundsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StepPlansFundsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
