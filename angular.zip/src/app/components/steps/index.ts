export * from './step-proposal-information/step-proposal-information.component';   
export * from './step-insured/step-insured.component';
export * from './step-insurer/step-insurer.component';
export * from './step-beneficiary/step-beneficiary.component';
export * from './step-plans-funds/step-plans-funds.component';
export * from './step-payment/step-payment.component';
export * from './step-summary/step-summary.component';