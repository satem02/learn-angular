import { Injectable } from "@angular/core";

@Injectable()
export class ContactModalService {
  public isOpen: boolean;

  show: (id:number) => void;

  constructor() {}
}
