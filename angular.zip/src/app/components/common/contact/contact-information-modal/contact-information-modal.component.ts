import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Pension2uFacade } from "src/app/+state";
import { PhoneContractInfo } from "src/app/models/service";
import { ContactModalService } from "../contact-modal.service";
import { ConstantsService } from "src/app/services/core/constants/constants.service";

@Component({
  selector: "app-contact-information-modal",
  templateUrl: "./contact-information-modal.component.html",
  styleUrls: ["./contact-information-modal.component.scss"],
  encapsulation: ViewEncapsulation.None
})
export class ContactInformationModalComponent implements OnInit {
  contractInformationModalForm: FormGroup;
  contractInfo: PhoneContractInfo = new PhoneContractInfo();
  contactTypeList$ = this.constantsService.getContactTypeList();
  countryCodeList$ = this.stateService.countryCodeList$;
  contactType$ = this.stateService.contactType$;
  id: number = 0;
  ServiceResponseMessage;
  _showSuccessMessage: boolean = false;
  _showErrorMessage: boolean = false;

  constructor(
    private formBuilder: FormBuilder,
    public modalService: ContactModalService,
    private stateService: Pension2uFacade,
    private constantsService: ConstantsService
  ) {
    modalService.show = this.show.bind(this);
  }

  ngOnInit() {
    this.createForm();
  }

  createForm() {
    this.contractInformationModalForm = this.formBuilder.group({
      countryCode: ["", Validators.required],
      communicationInfo: [],
      notes: []
    });
  }

  show(id: number) {
    this.id = id;
    if (id === 4) this.getCountryCodeForm().disable();
    else this.getCountryCodeForm().enable();

    this.clearForm();
    this.modalService.isOpen = true;
  }

  modalButtonClicked() {
    this.modalService.isOpen = false;
  }

  btnAddClick() {
    this.contractInfo.communicationOrder = this.id;
    this.contractInfo.displayText = this.contractInfo.communicationInfo;
    if (this.id === 1) {
      this.stateService.contactType$.subscribe(res => {
        res.homeWorkNumberList.push(this.contractInfo);
      });
    } else if (this.id === 2) {
      this.stateService.contactType$.subscribe(res => {
        res.faxList.push(this.contractInfo);
      });
    } else if (this.id === 3) {
      this.stateService.contactType$.subscribe(res => {
        res.mobileNumberList.push(this.contractInfo);
      });
    } else if (this.id === 4) {
      this.stateService.contactType$.subscribe(res => {
        res.emailList.push(this.contractInfo);
      });
    }
    this.showSuccessMessage("başarılı");
  }

  showSuccessMessage(message: string) {
    this._showSuccessMessage = true;
    this.ServiceResponseMessage = message;
  }

  showErrorMessage(message: string) {
    this._showErrorMessage = true;
    this.ServiceResponseMessage = message;
  }

  closeModal() {
    this.clearForm();
    this.modalService.isOpen = false;
  }

  clearForm() {
    this._showSuccessMessage = false;
    this._showErrorMessage = false;
    this.ServiceResponseMessage = "";
    this.contractInfo = new PhoneContractInfo();
  }

  getCountryCodeForm() {
    return this.contractInformationModalForm.get("countryCode");
  }
}
