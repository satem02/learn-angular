import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { NxButtonModule, NxModalModule } from "@allianz/ngx-ndbx";
import { TranslateModule } from "@ngx-translate/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { CustomNdbxModule } from "src/app/modules/ndbx-module";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { ContactModalService } from "./contact-modal.service";
import { ContactInformationModalComponent } from "./contact-information-modal/contact-information-modal.component";
import { ContactInformationComponent } from "./contact-information/contact-information.component";

@NgModule({
  declarations: [ContactInformationComponent, ContactInformationModalComponent],
  imports: [
    CustomNdbxModule,
    BrowserAnimationsModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    NxButtonModule,
    NxModalModule.forRoot(),
    TranslateModule.forChild()
  ],
  providers: [ContactModalService],
  exports: [ContactInformationComponent, ContactInformationModalComponent]
})
export class ContactModule {}
