import {
  Component,
  OnInit,
  ChangeDetectorRef,
  ChangeDetectionStrategy,
  Input
} from "@angular/core";
import { Pension2uFacade } from "src/app/+state";
import { FormGroup, FormBuilder } from "@angular/forms";
import { ContactModalService } from "../contact-modal.service";
import { PhoneContractInfo } from "src/app/models/service";
import { ContactInformationInfo } from "src/app/models/step/contact-information-info";

@Component({
  selector: "app-contact-information",
  templateUrl: "./contact-information.component.html",
  styleUrls: ["./contact-information.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ContactInformationComponent implements OnInit {
  contractInformationForm: FormGroup;
  contactList$ = this.stateService.contactType$;
  model: ContactInformationInfo = new ContactInformationInfo();
  @Input() parentFormGroup: FormGroup;

  ngOnInit() {
    this.createForm();
    this.addGroupToParent();
    this.initSelectedTypes();
  }

  constructor(
    private cdRef: ChangeDetectorRef,
    private formBuilder: FormBuilder,
    private stateService: Pension2uFacade,
    public modalService: ContactModalService
  ) {}

  createForm() {
    this.contractInformationForm = this.formBuilder.group({
      selectedHomeWorkPhone: [],
      selectedFax: [],
      selectedMobilePhone: [],
      selectedEPosta: []
    });
  }

  private addGroupToParent() {
    this.parentFormGroup.addControl(
      "contractInformation",
      this.contractInformationForm
    );
  }

  ngAfterViewInit() {
    this.cdRef.detectChanges();
  }

  initSelectedTypes() {
    this.contactList$.subscribe(res => {
      if (res.homeWorkNumberList) {
        this.model.selectedHomeWorkPhone = res.homeWorkNumberList.reduce(
          function(prev, current) {
            if (+current.communicationOrder > +prev.communicationOrder)
              return current;
            else return prev;
          }
        );
      }

      if (res.mobileNumberList) {
        this.model.selectedMobilePhone = res.mobileNumberList.reduce(function(
          prev,
          current
        ) {
          if (+current.communicationOrder > +prev.communicationOrder)
            return current;
          else return prev;
        });
      }

      if (res.faxList) {
        this.model.selectedFax = res.faxList.reduce(function(prev, current) {
          if (+current.communicationOrder > +prev.communicationOrder)
            return current;
          else return prev;
        });
      }

      if (res.emailList) {
        this.model.selectedEPosta = res.emailList.reduce(function(
          prev,
          current
        ) {
          if (+current.communicationOrder > +prev.communicationOrder)
            return current;
          else return prev;
        });
      }

      this.cdRef.detectChanges();
    });
  }

  homeWorkPhoneChange(contractInfo: PhoneContractInfo) {
    if (contractInfo != null && contractInfo.communicationOrder === -1)
      this.modalService.show(1);
  }

  faxChange(contractInfo: PhoneContractInfo) {
    if (contractInfo != null && contractInfo.communicationOrder === -1)
      this.modalService.show(2);
  }

  mobilePhoneChange(contractInfo: PhoneContractInfo) {
    if (contractInfo != null && contractInfo.communicationOrder === -1)
      this.modalService.show(3);
  }

  ePostaChange(contractInfo: PhoneContractInfo) {
    if (contractInfo != null && contractInfo.communicationOrder === -1)
      this.modalService.show(4);
  }

  selectHomeWorkPhone() {
    this.model.selectedHomeWorkPhone = new PhoneContractInfo();
  }
  selectFax() {
    this.model.selectedFax = new PhoneContractInfo();
  }
  selectMobilePhone() {
    this.model.selectedMobilePhone = new PhoneContractInfo();
  }
  selectEPosta() {
    this.model.selectedEPosta = new PhoneContractInfo();
  }
}
