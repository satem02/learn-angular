import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NxButtonModule, NxModalModule } from "@allianz/ngx-ndbx";
import { TranslateModule } from "@ngx-translate/core";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CustomNdbxModule } from 'src/app/modules/ndbx-module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { EducationOccupationalComponent } from './education-occupational.component';


@NgModule({
  declarations: [EducationOccupationalComponent],
  imports: [
    CustomNdbxModule,
    BrowserAnimationsModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    NxButtonModule,
    NxModalModule.forRoot(),
    TranslateModule.forChild()
  ],
  providers: [
  ],
  exports: [EducationOccupationalComponent
  ]
})
export class EducationOccupationalModule {
}
