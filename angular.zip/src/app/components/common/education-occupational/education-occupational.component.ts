import { Component, OnInit, Input } from "@angular/core";
import { Pension2uFacade } from "src/app/+state";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { EducationOccupationalInfo } from 'src/app/models/step/education-occupational-info';

@Component({
  selector: "app-education-occupational",
  templateUrl: "./education-occupational.component.html",
  styleUrls: ["./education-occupational.component.scss"]
})
export class EducationOccupationalComponent implements OnInit {
  EducationOccupationalFormGroup: FormGroup;
  @Input() parentFormGroup: FormGroup;

  jobList$ = this.service.jobList$;
  educationList$ = this.service.educationList$;
  incomeLevelList$ = this.service.incomeLevelList$;
  proposalInformation$ = this.service.proposalInformation$;

  model : EducationOccupationalInfo = new EducationOccupationalInfo();

  constructor(
    private formBuilder: FormBuilder,
    private service: Pension2uFacade
  ) {
    service.loadJobList();
    service.loadEducationList();
    service.loadIncomeLevelList();
  }

  ngOnInit() {
    this.createForm();
    this.addGroupToParent();
  }

  createForm() {
    this.EducationOccupationalFormGroup = this.formBuilder.group({
      desc: [""],
      job: [""],
      incomeLevel: [""],
      education: [""],
      registerNo: [""]
    });
  }

  private addGroupToParent() {
    this.parentFormGroup.addControl(
      "educationOccupationalInfo",
      this.EducationOccupationalFormGroup
    );
  }
}
