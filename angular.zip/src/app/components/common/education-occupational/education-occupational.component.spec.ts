import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EducationOccupationalComponent } from './education-occupational.component';

describe('EducationOccupationalComponent', () => {
  let component: EducationOccupationalComponent;
  let fixture: ComponentFixture<EducationOccupationalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EducationOccupationalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EducationOccupationalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
