import { Directive } from '@angular/core';
import { NG_VALIDATORS, Validator, FormControl } from '@angular/forms';

@Directive({
    selector: 'app-agency[required]',
    providers: [
        { provide: NG_VALIDATORS, useExisting: AgencyRequiredDirective, multi: true }
    ]
})
export class AgencyRequiredDirective implements Validator {

    validate(c: FormControl) {
        console.log(c.value);
        if (!c.value) {
            return {
                'required': 'Please choose a agency.'
            };
        }

        return null;
    }

}