import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NxButtonModule, NxModalModule } from "@allianz/ngx-ndbx";
import { TranslateModule } from "@ngx-translate/core";
import { AddressInfoComponent } from './address-info/address-info.component';
import { AddressListComponent } from './address-list/address-list.component';
import { AddressModalService } from './address-modal.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CustomNdbxModule } from 'src/app/modules/ndbx-module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AddressResidenceComponent } from './address-residence/address-residence.component';
import { AddressResidenceListComponent } from './address-residence-list/address-residence-list.component';
import { AddressResidentListComponent } from './address-resident-list/address-resident-list.component';
import { AddressResidentComponent } from './address-resident/address-resident.component';
import { AddressComponent } from './address/address.component';
import { AddressResidenceModalService } from './address-residence-modal.service';
import { AddressResidentModalService } from './address-resident-modal.service';


@NgModule({
  declarations: [AddressInfoComponent, AddressListComponent, AddressResidenceComponent, AddressResidenceListComponent, AddressResidentListComponent, AddressResidentComponent, AddressComponent],
  imports: [
    CustomNdbxModule,
    BrowserAnimationsModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    NxButtonModule,
    NxModalModule.forRoot(),
    TranslateModule.forChild()
  ],
  providers: [
    AddressModalService,
    AddressResidenceModalService,
    AddressResidentModalService
  ],
  exports: [
    AddressInfoComponent,
    AddressListComponent, 
    AddressResidenceComponent, 
    AddressResidenceListComponent, 
    AddressResidentListComponent, 
    AddressResidentComponent,
    AddressComponent
  ]
})
export class AddressModule {
}
