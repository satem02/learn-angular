import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddressResidentComponent } from './address-resident.component';

describe('AddressResidentComponent', () => {
  let component: AddressResidentComponent;
  let fixture: ComponentFixture<AddressResidentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddressResidentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddressResidentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
