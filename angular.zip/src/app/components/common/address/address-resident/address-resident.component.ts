import { Component, OnInit, ViewEncapsulation, ChangeDetectorRef } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { AddressInfo } from "src/app/models/service/address-info/address-info";
import { Pension2uFacade } from "src/app/+state";
import { AddressResidentModalService } from "../address-resident-modal.service";

@Component({
  selector: "app-address-resident",
  templateUrl: "./address-resident.component.html",
  styleUrls: ["./address-resident.component.scss"],
  encapsulation: ViewEncapsulation.None
})
export class AddressResidentComponent implements OnInit {
  AddressResidentFormGroup: FormGroup;
  addressInfo: AddressInfo = new AddressInfo();
  countryList$;
  ServiceResponseMessage;
  _showSuccessMessage: boolean = false;
  _showErrorMessage: boolean = false;

  constructor(
    private cdRef: ChangeDetectorRef,
    private formBuilder: FormBuilder,
    public modalAddressService: AddressResidentModalService,
    private stateService: Pension2uFacade
  ) {
    modalAddressService.show = this.show.bind(this);
  }

  ngOnInit(): void {
    this.createForm();

    this.stateService.countryList$.subscribe(res => {
      this.countryList$ = res.filter(x => x.code != "TR");
    });
  }

  createForm() {
    this.AddressResidentFormGroup = this.formBuilder.group({
      countryCode: [""],
      districtCode: [""],
      addressArea1: [""]
    });
  }

  show() {
    this.modalAddressService.isOpen = true;
    this.cdRef.detectChanges();
  }

  modalButtonClicked() {
    this.modalAddressService.isOpen = false;
  }

  btnAddClick() {
    // adres ekleme servisi çağırımı
    this.stateService.residenteAddressContractList$.subscribe(res => {
      this.addressInfo.displayAddress = this.addressInfo.addressArea1;
      this.addressInfo.id = Math.floor(Math.random() * 100) + 10;
      this.addressInfo.addressType = 4;
      res.push(this.addressInfo);
    });
    this.showSuccessMessage("başarılı");
  }

  showSuccessMessage(message: string) {
    this._showSuccessMessage = true;
    this.ServiceResponseMessage = message;
  }

  showErrorMessage(message: string) {
    this._showErrorMessage = true;
    this.ServiceResponseMessage = message;
  }

  btnKPSSearchClick() {
    this.showErrorMessage("başarasız");
  }

  closeModal() {
    this.clearForm();
    this.modalAddressService.isOpen = false;
  }

  clearForm() {
    this._showSuccessMessage = false;
    this._showErrorMessage = false;
    this.addressInfo = new AddressInfo();
  }
}
