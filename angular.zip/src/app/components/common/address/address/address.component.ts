import { Component, OnInit, Input } from "@angular/core";
import { FormGroup, FormBuilder } from "@angular/forms";

@Component({
  selector: "app-address",
  templateUrl: "./address.component.html",
  styleUrls: ["./address.component.scss"]
})
export class AddressComponent implements OnInit {
  allAddressInfoFormGroup: FormGroup;
  @Input() parentFormGroup: FormGroup;

  constructor(private formBuilder: FormBuilder) {}

  ngOnInit() {
    this.createForm();
    this.addGroupToParent();
  }

  createForm() {
    this.allAddressInfoFormGroup = this.formBuilder.group({
      
    });
  }

  private addGroupToParent() {
    this.parentFormGroup.addControl(
      "allAddressInfo",
      this.allAddressInfoFormGroup
    );
  }
}
