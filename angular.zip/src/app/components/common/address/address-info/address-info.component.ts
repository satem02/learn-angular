import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { AddressModalService } from '../address-modal.service';
import { AddressInfo } from 'src/app/models/service/address-info/address-info';
import { Pension2uFacade } from 'src/app/+state';
import { DistrictInfoRequest } from 'src/app/models/service/district-info/district-info-request';
import { Pension2uDataService } from 'src/app/services/pension2u-data.service';

@Component({
  selector: 'app-address-info',
  templateUrl: './address-info.component.html',
  styleUrls: ['./address-info.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AddressInfoComponent implements OnInit {

  AddressInfoFormGroup: FormGroup;
  addressInfo: AddressInfo = new AddressInfo();
  countryList$ = this.stateService.countryList$;
  provinceList$ = this.stateService.provinceList$;
  districtList$ ;
  ServiceResponseMessage;
  _showSuccessMessage: boolean = false;
  _showErrorMessage: boolean = false;

  constructor(private formBuilder: FormBuilder, public modalAddressService: AddressModalService, private stateService: Pension2uFacade , private dataService:Pension2uDataService) {
    modalAddressService.show = this.show.bind(this);
  }

  ngOnInit(): void {
    this.addressInfo.countryCode = "TR";
    this.createForm();
  }

  createForm() {
    this.AddressInfoFormGroup = this.formBuilder.group({
      countryCode: [''],
      provinceCode: [''],
      districtCode: [''],
      zipCode: [''],
      addressArea1: [''],
      addressArea2: [''],
      addressArea3: ['']
    });
  }

  show() {
    this.modalAddressService.isOpen = true;
  }

  modalButtonClicked() {
    this.modalAddressService.isOpen = false;
  }

  btnAddClick() {
    // adres ekleme servisi çağırımı
    this.stateService.addressContractInfoList$.subscribe(res => {
      this.addressInfo.displayAddress = this.addressInfo.addressArea1 + " "  + this.addressInfo.addressArea2 + " " + this.addressInfo.addressArea3;
      this.addressInfo.id = Math.floor(Math.random() * 100) + 10;
      this.addressInfo.addressType = 3;
      res.push(this.addressInfo)
    });
    this.showSuccessMessage("başarılı");
  }

  showSuccessMessage(message: string) {
    this._showSuccessMessage = true;
    this.ServiceResponseMessage = message;
  }

  showErrorMessage(message: string) {
    this._showErrorMessage = true;
    this.ServiceResponseMessage = message;
  }

  btnKPSSearchClick() {
    this.showErrorMessage("başarasız");
  }

  closeModal() {
    this.clearForm();
    this.modalAddressService.isOpen = false
  }

  clearForm() {
    this._showSuccessMessage = false;
    this._showErrorMessage = false;
    this.addressInfo = new AddressInfo();
  }

  provinceChange(event){
    var request = new DistrictInfoRequest();
    request.cityCode = event;

    this.districtList$ = this.dataService.getDistricts(request);

  }
}
