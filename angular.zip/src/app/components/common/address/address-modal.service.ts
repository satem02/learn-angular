import { Injectable } from "@angular/core";
import { Observable } from "rxjs";

@Injectable()
export class AddressModalService {

  public isOpen: boolean;

  show: () => void;


  constructor() {

  }
}
