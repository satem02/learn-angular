import {
  Component,
  OnInit,
  ChangeDetectorRef,
  ChangeDetectionStrategy,
  Input
} from "@angular/core";
import { AddressModalService } from "../address-modal.service";
import { Pension2uFacade } from "src/app/+state";
import { AddressInfo } from "src/app/models/service/address-info/address-info";
import { FormGroup, FormControl, FormBuilder } from "@angular/forms";

@Component({
  selector: "app-address-list",
  templateUrl: "./address-list.component.html",
  styleUrls: ["./address-list.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AddressListComponent implements OnInit {
  addressList$ = this.service.addressContractInfoList$;
  _equalContact: boolean = false;
  addressContactValue: string = "Yes";
  selectedAddress: AddressInfo = new AddressInfo();
  @Input() parentFormGroup: FormGroup;
  addressContactFormGroup: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private cdRef: ChangeDetectorRef,
    public modalAddressService: AddressModalService,
    private service: Pension2uFacade
  ) {}

  ngAfterViewInit() {
    this.cdRef.detectChanges();
  }

  ngOnInit() {
    this.createForm();
  }

  createForm() {
    this.addressContactFormGroup = this.formBuilder.group({
      selectedAddress: this.selectedAddress,
      isEqualResidenceContact: [this.addressContactValue]
    });
    this.addGroupToParent();
    this.cdRef.detectChanges();
  }
  private addGroupToParent() {
    this.parentFormGroup.addControl(
      "contactAddressInfo",
      this.addressContactFormGroup
    );
  }

  addressContactChange($event: any) {
    this._equalContact = $event.value == "No";
  }

  addressChange(address: AddressInfo) {
    if (address != null && address.addressType === 1 && address.id === 0)
      this.modalAddressService.show();
    this.cdRef.detectChanges();
  }

  selectItem() {
    this.selectedAddress = new AddressInfo();
    this.cdRef.detectChanges();
  }
}
