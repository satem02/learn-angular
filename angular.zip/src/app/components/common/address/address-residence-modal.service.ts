import { Injectable } from "@angular/core";
import { Observable } from "rxjs";

@Injectable()
export class AddressResidenceModalService {

  public isOpen: boolean;

  show: () => void;


  constructor() {

  }
}
