import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddressResidentListComponent } from './address-resident-list.component';

describe('AddressResidentListComponent', () => {
  let component: AddressResidentListComponent;
  let fixture: ComponentFixture<AddressResidentListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddressResidentListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddressResidentListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
