import {
  Component,
  OnInit,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Input
} from "@angular/core";
import { Pension2uFacade } from "src/app/+state";
import { AddressResidentModalService } from "../address-resident-modal.service";
import { AddressInfo } from "src/app/models/service/address-info/address-info";
import { FormGroup, FormControl, FormBuilder } from "@angular/forms";

@Component({
  selector: "app-address-resident-list",
  templateUrl: "./address-resident-list.component.html",
  styleUrls: ["./address-resident-list.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AddressResidentListComponent implements OnInit {
  addressList$ = this.service.residenteAddressContractList$;
  _equalContact: boolean = false;
  addressContactValue: string = "No";
  addressContactValue1: string = "";
  selectedAddress: AddressInfo = new AddressInfo();
  @Input() parentFormGroup: FormGroup;
  addressResidentFormGroup:FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private cdRef: ChangeDetectorRef,
    public modalAddressService: AddressResidentModalService,
    private service: Pension2uFacade
  ) {}

  ngAfterViewInit() {
    this.cdRef.detectChanges();
  }

  ngOnInit() {
    this.createForm();
  }

  createForm() {
    this.addressResidentFormGroup = this.formBuilder.group({
      selectedAddress: this.selectedAddress,
      hasResidentAddress: [this.addressContactValue],
      hasResidentCertificaReceived:[this.addressContactValue1]
    });
    this.addGroupToParent();
    this.cdRef.detectChanges();
  }

  private addGroupToParent() {
    this.parentFormGroup.addControl(
      "residentAddressInfo",
      this.addressResidentFormGroup
    );
  }

  addressContactChange($event: any) {
    this._equalContact = $event.value == "Yes";
    this.cdRef.detectChanges();
  }

  addressContactChange1($event: any) {}

  addressChange(address: AddressInfo) {
    if (address != null && address.addressType === 1 && address.id === 0)
      this.modalAddressService.show();
      this.cdRef.detectChanges();
  }

  selectItem() {
    this.selectedAddress = new AddressInfo();
    this.cdRef.detectChanges();
  }
}
