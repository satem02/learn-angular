import { Component, OnInit, ViewEncapsulation, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { AddressInfo } from 'src/app/models/service/address-info/address-info';
import { Pension2uFacade } from 'src/app/+state';
import { AddressResidenceModalService } from '../address-residence-modal.service';
import { DistrictInfoRequest } from 'src/app/models/service/district-info/district-info-request';
import { Pension2uDataService } from 'src/app/services/pension2u-data.service';

@Component({
  selector: 'app-address-residence',
  templateUrl: './address-residence.component.html',
  styleUrls: ['./address-residence.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AddressResidenceComponent implements OnInit {

  AddressResidenceFormGroup: FormGroup;
  addressInfo: AddressInfo = new AddressInfo();
  districtList$;
  countryList$ = this.stateService.countryList$;
  provinceList$ = this.stateService.provinceList$;
  ServiceResponseMessage;
  _showSuccessMessage: boolean = false;
  _showErrorMessage: boolean = false;

  constructor(
    private cdRef: ChangeDetectorRef,private dataService:Pension2uDataService,private formBuilder: FormBuilder, public modalAddressService: AddressResidenceModalService, private stateService: Pension2uFacade) {
    modalAddressService.show = this.show.bind(this);
  }

  ngOnInit(): void {
    this.addressInfo.countryCode = "TR";
    this.createForm();
  }

  createForm() {
    this.AddressResidenceFormGroup = this.formBuilder.group({
      countryCode: [''],
      provinceCode: [''],
      districtCode: [''],
      zipCode: [''],
      addressArea1: [''],
      addressArea2: [''],
      addressArea3: ['']
    });
  }

  show() {
    this.modalAddressService.isOpen = true;
    this.cdRef.detectChanges();
  }

  modalButtonClicked() {
    this.modalAddressService.isOpen = false;
  }

  btnAddClick() {
    // adres ekleme servisi çağırımı
    this.stateService.residenceAddressContractList$.subscribe(res => {
      this.addressInfo.displayAddress = this.addressInfo.addressArea1 + " "  + this.addressInfo.addressArea2 + " " + this.addressInfo.addressArea3;
      this.addressInfo.id = Math.floor(Math.random() * 100) + 10;
      this.addressInfo.addressType = 2;
      res.push(this.addressInfo)
    });
    this.showSuccessMessage("başarılı");
  }

  showSuccessMessage(message: string) {
    this._showSuccessMessage = true;
    this.ServiceResponseMessage = message;
  }

  showErrorMessage(message: string) {
    this._showErrorMessage = true;
    this.ServiceResponseMessage = message;
  }

  btnKPSSearchClick() {
    this.showErrorMessage("başarasız");
  }

  closeModal() {
    this.clearForm();
    this.modalAddressService.isOpen = false
  }

  clearForm() {
    this._showSuccessMessage = false;
    this._showErrorMessage = false;
    this.addressInfo = new AddressInfo();
  }

  provinceChange(event){
    var request = new DistrictInfoRequest();
    request.cityCode = event;
    this.districtList$ = this.dataService.getDistricts(request);

  }
}

