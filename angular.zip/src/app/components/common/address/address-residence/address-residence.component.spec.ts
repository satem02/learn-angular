import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddressResidenceComponent } from './address-residence.component';

describe('AddressResidenceComponent', () => {
  let component: AddressResidenceComponent;
  let fixture: ComponentFixture<AddressResidenceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddressResidenceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddressResidenceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
