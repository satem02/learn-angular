import {
  Component,
  OnInit,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Input
} from "@angular/core";
import { Pension2uFacade } from "src/app/+state";
import { AddressResidenceModalService } from "../address-residence-modal.service";
import { AddressInfo } from "src/app/models/service/address-info/address-info";
import { FormGroup, FormBuilder, FormControl } from "@angular/forms";

@Component({
  selector: "app-address-residence-list",
  templateUrl: "./address-residence-list.component.html",
  styleUrls: ["./address-residence-list.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AddressResidenceListComponent implements OnInit {
  addressList$ = this.service.residenceAddressContractList$;
  selectedAddress: AddressInfo = new AddressInfo();

  @Input() parentFormGroup: FormGroup;
  addressResidenceFormGroup: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private cdRef: ChangeDetectorRef,
    public modalAddressService: AddressResidenceModalService,
    private service: Pension2uFacade
  ) {}

  ngAfterViewInit() {
    this.cdRef.detectChanges();
  }

  ngOnInit() {
    this.createForm();
    this.addressList$.subscribe(res => {
      var row = res.find(p => p.addressType == 2);
      if (row) {
        this.selectedAddress = row;
      }
      this.cdRef.detectChanges();
    });
  }
  createForm() {
    this.addressResidenceFormGroup = this.formBuilder.group({
      selectedAddress: this.selectedAddress
    });
    this.addGroupToParent();
    this.cdRef.detectChanges();
  }

  private addGroupToParent() {
    this.parentFormGroup.addControl(
      "residenceAddressInfo",
      this.addressResidenceFormGroup
    );
  }

  addressChange(address: AddressInfo) {
    if (address != null && address.addressType === 1 && address.id === 0)
      this.modalAddressService.show();
      this.cdRef.detectChanges();
  }

  selectItem() {
    this.selectedAddress = new AddressInfo();
    this.cdRef.detectChanges();
  }
}
