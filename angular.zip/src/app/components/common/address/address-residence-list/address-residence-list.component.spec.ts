import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddressResidenceListComponent } from './address-residence-list.component';

describe('AddressResidenceListComponent', () => {
  let component: AddressResidenceListComponent;
  let fixture: ComponentFixture<AddressResidenceListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddressResidenceListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddressResidenceListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
