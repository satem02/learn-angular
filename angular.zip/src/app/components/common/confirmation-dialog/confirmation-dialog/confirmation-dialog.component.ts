import { Component, OnInit } from '@angular/core';
import { Observable, Subject } from "rxjs";
import { ModalButton, ModalButtonCombinations } from '../confirmation-dialog.enums';
import { ConfirmationDialogService } from '../confirmation-dialog.service';

@Component({
  selector: 'app-confirmation-dialog',
  templateUrl: './confirmation-dialog.component.html',
  styleUrls: ['./confirmation-dialog.component.scss']
})
export class ConfirmationDialogComponent implements OnInit {
  
  ngOnInit(): void {
  }

  title: string;
  message: string;
  modalButton = ModalButton;
  buttons: ModalButtonCombinations;
  defaultButton: ModalButton;
  defaults = {
    title: undefined,
    message: undefined,
    buttons: ModalButtonCombinations.OkCancel,
    defaultButton: ModalButton.Cancel
  };
  private response = new Subject<ModalButton>();
  private response$ = this.response.asObservable();

  constructor(public modalDialogService: ConfirmationDialogService) {
    modalDialogService.show = this.show.bind(this);
    modalDialogService.terminate = this.terminate.bind(this);
  }

  isButtonDisplay(button: ModalButton) {

    let display = false;

    if (button === ModalButton.Ok &&
      (this.buttons === ModalButtonCombinations.Ok || this.buttons === ModalButtonCombinations.OkCancel))
      display = true;
    else if (button === ModalButton.Cancel &&
      (this.buttons === ModalButtonCombinations.OkCancel || this.buttons === ModalButtonCombinations.RetryCancel
        || this.buttons === ModalButtonCombinations.YesNoCancel || this.buttons === ModalButtonCombinations.Cancel
        || this.buttons === ModalButtonCombinations.AbortRetryCancel))
      display = true;
    else if (button === ModalButton.Retry &&
      (this.buttons === ModalButtonCombinations.RetryCancel || this.buttons === ModalButtonCombinations.AbortRetryCancel))
      display = true;
    else if (button === ModalButton.Yes &&
      (this.buttons === ModalButtonCombinations.YesNo || this.buttons === ModalButtonCombinations.YesNoCancel))
      display = true;
    else if (button === ModalButton.No &&
      (this.buttons === ModalButtonCombinations.YesNo || this.buttons === ModalButtonCombinations.YesNoCancel))
      display = true;
    else if (button === ModalButton.Abort &&
      (this.buttons === ModalButtonCombinations.AbortRetryCancel))
      display = true;

    return display;

  }

  setLabels(message = this.defaults.message, title = this.defaults.title, buttons = this.defaults.buttons, defaultButton = this.defaults.defaultButton) {
    this.title = title;
    this.message = message;
    this.buttons = buttons;
    this.defaultButton = defaultButton;
  }

  terminate() {
    return true;
  }

  show(message = this.defaults.message, title = this.defaults.title, buttons = this.defaults.buttons, defaultButton = this.defaults.defaultButton): Observable<ModalButton> {
    this.setLabels(message, title, buttons, defaultButton);
    this.modalDialogService.isOpen = true;
    return this.response$;
  }

  modalButtonClicked(button: ModalButton) {
    this.response.next(button);
    this.modalDialogService.isOpen = false;
  }

}
