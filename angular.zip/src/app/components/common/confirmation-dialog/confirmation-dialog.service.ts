import { Injectable } from "@angular/core";
import { ModalButton, ModalButtonCombinations } from "./confirmation-dialog.enums";
import { Observable } from "rxjs";

@Injectable()
export class ConfirmationDialogService {

  public isOpen: boolean;

  show: (message?: string,
    title?: string,
    buttons?: ModalButtonCombinations,
    defaultButton?: ModalButton) => Observable<ModalButton>;

  terminate: () => ModalButton;

  constructor() {

  }

}
