import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConfirmationDialogComponent } from './confirmation-dialog/confirmation-dialog.component';
import { ConfirmationDialogService } from "./confirmation-dialog.service";
import { NxButtonModule, NxModalModule } from "@allianz/ngx-ndbx";
import { TranslateModule } from "@ngx-translate/core";

@NgModule({
  declarations: [ConfirmationDialogComponent],
  imports: [
    CommonModule,
    NxButtonModule,
    NxModalModule.forRoot(),
    TranslateModule.forChild()
  ],
  providers: [
    ConfirmationDialogService
  ],
  exports: [
    ConfirmationDialogComponent
  ]
})
export class ConfirmationDialogModule {
}
