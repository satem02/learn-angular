import { Component, OnInit, ChangeDetectorRef, Inject, Input } from "@angular/core";
import { FormGroup, FormBuilder } from "@angular/forms";
import { Pension2uFacade } from "src/app/+state";
import { ContactModalService } from "../../contact/contact-modal.service";
import { FatcaInfo } from "src/app/models/service";
import {
  AppConstants,
  IAppConstants
} from "src/app/models/common/app-constants";
import { Pension2uDataService } from 'src/app/services/pension2u-data.service';

@Component({
  selector: "app-fatca-information",
  templateUrl: "./fatca-information.component.html",
  styleUrls: ["./fatca-information.component.scss"]
})
export class FatcaInformationComponent implements OnInit {
  fatcaInformationForm: FormGroup;
  identityRegisterTypes$ = this.dataService.getIdentityRegisterTypes();
  countryList$ = this.stateService.countryList$;
  fatcaInfo: FatcaInfo = new FatcaInfo();
  showUSDetail: boolean = false;
  @Input() parentFormGroup: FormGroup;

  ngOnInit() {
    this.createForm();
  }
  constructor(
    @Inject(AppConstants) private constants: IAppConstants,
    private cdRef: ChangeDetectorRef,
    private formBuilder: FormBuilder,
    private stateService: Pension2uFacade,
    private dataService:Pension2uDataService,
    public modalService: ContactModalService
  ) {}

  createForm() {
    this.fatcaInformationForm = this.formBuilder.group({
      countryTaxpayer: [],
      countryOfBirth: [],
      residenceABD: [],
      identityType: [],
      identitySerialNo: [],
      hasDoubleCitzenship: [],
      foreignTelNo: []
    });

    this.addGroupToParent();
  }


  private addGroupToParent() {
    this.parentFormGroup.addControl(
      "fatcaInfo",
      this.fatcaInformationForm
    );
  }

  usDetailChange() {
    if (
      this.fatcaInfo.residenceABD == this.constants.YES ||
      this.fatcaInfo.countryOfBirth.code == this.constants.US ||
      this.fatcaInfo.countryTaxpayer.code == this.constants.US
    )
      this.showUSDetail = true;
    else {
      this.fatcaInfo.identityType = null;
      this.fatcaInfo.identitySerialNo = null;
      this.fatcaInfo.hasDoubleCitzenship = null;
      this.fatcaInfo.foreignTelNo = null;
      this.showUSDetail = false;
    }
  }
}
