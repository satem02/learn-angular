import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FatcaInformationComponent } from './fatca-information.component';

describe('FatcaInformationComponent', () => {
  let component: FatcaInformationComponent;
  let fixture: ComponentFixture<FatcaInformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FatcaInformationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FatcaInformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
