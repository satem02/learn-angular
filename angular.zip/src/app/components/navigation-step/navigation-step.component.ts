import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { STEPPER_GLOBAL_OPTIONS } from '@angular/cdk/stepper';
import { NavigationFormService } from './navigation-form.service';
import * as Steps from '../steps/index';
import { Pension2uFacade } from 'src/app/+state/pension2u.facade';
import { LogEngineService } from 'src/app/services/core/log/log-engine.service';
import { ActivatedRoute } from '@angular/router';
import { CustomerInfoRequest } from 'src/app/models/service/customer-info/customer-info-request';
import { CompanyInfoRequest } from 'src/app/models/service/company-info/company-info-request';

@Component({
  selector: 'app-navigation-step',
  templateUrl: './navigation-step.component.html',
  styleUrls: ['./navigation-step.component.scss'],
  providers: [NavigationFormService, {
    provide: STEPPER_GLOBAL_OPTIONS, useValue: { showError: true }
  }]
})

export class NavigationStepComponent implements OnInit {

  customerTCKN: string;

  constructor(private ref: ChangeDetectorRef, private service: Pension2uFacade, private logger: LogEngineService, private activatedRoute: ActivatedRoute) {
    this.readRouteParameter();
    this.loadState();
  }

  readRouteParameter() {
    this.activatedRoute.params.subscribe(p => {
      this.customerTCKN = p["customerTCKN"];
    });
  }

  loadState() {
    this.loadCompanyList();
    this.loadCustomerInfo();
    this.loadContractList();
  }

  loadCustomerInfo() {
    var request = new CustomerInfoRequest();
    request.tckn = this.customerTCKN;
    this.service.loadCustomerInfo(request);
  }

  loadCompanyList() {
    var request = new CompanyInfoRequest();
    request.tckn = this.customerTCKN;
    this.service.loadCompanyList(request);
  }
  
  loadContractList() {
    this.service.loadContractList();
  }

  @ViewChild(Steps.StepProposalInformationComponent, { static: false }) ProposalInformationComponent: Steps.StepProposalInformationComponent;
  @ViewChild(Steps.StepInsuredComponent, { static: false }) InsuredComponent: Steps.StepInsuredComponent;
  @ViewChild(Steps.StepInsurerComponent, { static: false }) InsurerComponent: Steps.StepInsurerComponent;
  @ViewChild(Steps.StepBeneficiaryComponent, { static: false }) BeneficiaryComponent: Steps.StepBeneficiaryComponent;
  @ViewChild(Steps.StepPlansFundsComponent, { static: false }) PlansFundsComponent: Steps.StepPlansFundsComponent;
  @ViewChild(Steps.StepPaymentComponent, { static: false }) PaymentComponent: Steps.StepPaymentComponent;
  @ViewChild(Steps.StepSummaryComponent, { static: false }) SummaryComponent: Steps.StepSummaryComponent;

  ngAfterViewInit() {
    this.ref.detectChanges();
  }

  get frmStepProposalInformation() {
    return this.ProposalInformationComponent ? this.ProposalInformationComponent.ProposalInformationFormGroup : null;
  }

  get frmInsured() {
    return this.InsuredComponent ? this.InsuredComponent.InsuredDetailFormGroup : null;
  }
  get frmInsurer() {
    return this.InsurerComponent ? this.InsurerComponent.InsurerFormGroup : null;
  }
  get frmBeneficiary() {
    return this.BeneficiaryComponent ? this.BeneficiaryComponent.BeneficiaryFormGroup : null;
  }
  get frmPlansFunds() {
    return this.PlansFundsComponent ? this.PlansFundsComponent.PlansFundsFormGroup : null;
  }
  get frmPayment() {
    return this.PaymentComponent ? this.PaymentComponent.PaymentFormGroup : null;
  }
  get frmSummary() {
    return this.SummaryComponent ? this.SummaryComponent.SummaryFormGroup : null;
  }

  ngOnInit() {

  }

}