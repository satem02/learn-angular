import { LogLevel } from 'src/app/services/core/log/log-level';

export const environment = {
  production: true,
  logLevel:LogLevel.All,
  apiURL: './'
};
